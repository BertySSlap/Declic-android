# Déclic Usager 1.5.7 / serveur V11.9.1

- Après validation d’une commande de carte, « Ma carte Déclic » devient immédiatement disponible en tête du sélecteur du Point Déclic quotidien, même si le serveur est temporairement hors ligne. Le QR personnel est créé à la reconnexion.
- Un scan refusé (mauvais Point, mauvais jour, trop tard, etc.) ne peut plus laisser un faux état « déjà validé aujourd’hui ». Le serveur est l’autorité et les anciens marqueurs locaux erronés sont nettoyés.
- Compatibilité Wi-Fi conservée.
