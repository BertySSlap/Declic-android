# Déclic Usager 1.5.1-server

## Scan réussi
Quand le serveur accepte le QR :
- la validation est enregistrée côté serveur ;
- points / récurrence / statistiques sont mis à jour ;
- l'étape « Je scanne mon Point Déclic » passe à ✓ ;
- l'application revient automatiquement sur Accueil.

## Refus
- QR inconnu : « Le QR code ne correspond pas à un Point Déclic connu »
- QR impossible à décoder : « QR code illisible »
- mauvais Point du jour : popup « Mauvais Point Déclic »
- jour de pause : popup « Mauvais jour »
- trop tard : popup « Vous arrivez trop tard malheureusement »

## Roues de secours
- petit retard : crédit retard 2 € (10 min supplémentaires par défaut)
- routine manquée : joker
- 1 joker inclus / mois
- joker supplémentaire : 3,90 €
- maximum 2 jokers supplémentaires / mois

Toutes les décisions d'heure utilisent le serveur et le fuseau du Point Déclic, pas l'heure réglée sur le téléphone.
