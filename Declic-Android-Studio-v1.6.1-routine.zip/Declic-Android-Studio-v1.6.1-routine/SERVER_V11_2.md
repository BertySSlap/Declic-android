# Déclic Usager 1.4.9-server — QR V11.3

- QR commerçant résolu côté serveur.
- Carte personnelle liée à un seul `user_id`.
- Une carte d'un autre usager renvoie HTTP 403 / `PERSONAL_CARD_NOT_OWNER`.
- Le QR personnel affiché dans l'app est récupéré depuis `/api/personal-cards`.
- Quand le serveur est connecté, l'ancien QR local ne contourne plus la vérification serveur.
