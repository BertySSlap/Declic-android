@echo off
title Serveur prototype Declic
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js est necessaire pour lancer ce serveur.
  pause
  exit /b 1
)
node server.js
pause
