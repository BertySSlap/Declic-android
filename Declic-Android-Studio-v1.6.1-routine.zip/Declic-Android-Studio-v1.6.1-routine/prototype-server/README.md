# Serveur prototype Déclic

1. Installez Node.js sur le PC si nécessaire.
2. Double-cliquez sur `start-server.bat`.
3. Placez le téléphone et le PC sur le même réseau.
4. Dans **Espace Points Déclic > Proposer un commerce > Serveur du prototype**, indiquez l’adresse IP du PC, par exemple :

   `http://192.168.43.200:8000/api/merchant-proposals`

Les propositions reçues sont enregistrées dans `data/merchant-proposals.json`. Cette liaison HTTP est réservée au prototype local. La version de production devra utiliser une API HTTPS authentifiée.

## Voir les commandes en temps réel

Ouvrez `http://localhost:8000` dans le navigateur du PC. Le tableau se met à jour chaque seconde et affiche :

- les nouvelles commandes de cartes reçues depuis le téléphone ;
- les commerces proposés depuis l’application.

Dans **Personnaliser ma carte Déclic > Serveur des commandes du prototype**, utilisez la même adresse IP que pour les propositions, avec le chemin `/api/card-orders`, par exemple `http://192.168.43.200:8000/api/card-orders`.

Les commandes sont enregistrées dans `data/card-orders.json`. Le téléphone et le PC doivent être sur le même réseau Wi-Fi, et le pare-feu Windows doit autoriser Node.js sur le réseau privé.
