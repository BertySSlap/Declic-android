'use strict';

const http=require('node:http');
const fs=require('node:fs');
const path=require('node:path');

const port=Number(process.env.DECLIC_SERVER_PORT)||8000;
const proposalDataFile=process.env.DECLIC_DATA_FILE||path.join(__dirname,'data','merchant-proposals.json');
const orderDataFile=process.env.DECLIC_ORDER_DATA_FILE||path.join(__dirname,'data','card-orders.json');
const dashboardFile=path.join(__dirname,'dashboard.html');

function send(response,status,payload){
  response.writeHead(status,{
    'Content-Type':'application/json; charset=utf-8',
    'Access-Control-Allow-Origin':'*',
    'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers':'Content-Type,Accept',
    'Cache-Control':'no-store'
  });
  response.end(JSON.stringify(payload));
}

function readAll(file){
  try{return JSON.parse(fs.readFileSync(file,'utf8'));}
  catch(_error){return [];}
}

function saveAll(file,items){
  fs.mkdirSync(path.dirname(file),{recursive:true});
  fs.writeFileSync(file,JSON.stringify(items,null,2),'utf8');
}

function readJson(request,maxBytes){
  return new Promise((resolve,reject)=>{
    let body='';
    request.setEncoding('utf8');
    request.on('data',chunk=>{
      body+=chunk;
      if(body.length>(maxBytes||65536)){reject(new Error('payload-too-large'));request.destroy();}
    });
    request.on('end',()=>{try{resolve(JSON.parse(body||'{}'));}catch(_error){reject(new Error('invalid-json'));}});
    request.on('error',reject);
  });
}

const server=http.createServer(async(request,response)=>{
  if(request.method==='OPTIONS'){send(response,204,{});return;}
  if(request.url==='/'&&request.method==='GET'){
    response.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'});
    response.end(fs.readFileSync(dashboardFile,'utf8'));return;
  }
  if(request.url==='/health'&&request.method==='GET'){send(response,200,{ok:true,service:'declic-prototype'});return;}
  if(request.url==='/api/merchant-proposals'&&request.method==='GET'){
    send(response,200,{ok:true,proposals:readAll(proposalDataFile)});return;
  }
  if(request.url==='/api/merchant-proposals'&&request.method==='POST'){
    try{
      const proposal=await readJson(request);
      const name=String(proposal.name||'').trim();
      const address=String(proposal.address||'').trim();
      if(!name||!address){send(response,400,{ok:false,error:'name-and-address-required'});return;}
      const stored={...proposal,id:String(proposal.id||'proposal-'+Date.now()),name,address,receivedAt:new Date().toISOString(),status:'reçu'};
      const all=readAll(proposalDataFile);all.push(stored);saveAll(proposalDataFile,all.slice(-500));
      send(response,201,{ok:true,id:stored.id,status:'received'});
    }catch(error){send(response,error.message==='payload-too-large'?413:400,{ok:false,error:error.message});}
    return;
  }
  if(request.url==='/api/card-orders?summary=1'&&request.method==='GET'){
    const orders=readAll(orderDataFile).map(({design,...order})=>({...order,designIncluded:!!design}));
    send(response,200,{ok:true,orders});return;
  }
  if(request.url==='/api/card-orders'&&request.method==='GET'){
    send(response,200,{ok:true,orders:readAll(orderDataFile)});return;
  }
  if(request.url==='/api/card-orders'&&request.method==='POST'){
    try{
      const order=await readJson(request,5*1024*1024);
      const displayName=String(order.displayName||'').trim();
      if(!displayName||!order.design){send(response,400,{ok:false,error:'name-and-design-required'});return;}
      const stored={...order,id:String(order.id||'card-order-'+Date.now()),displayName,receivedAt:new Date().toISOString(),status:'reçu'};
      const all=readAll(orderDataFile);all.push(stored);saveAll(orderDataFile,all.slice(-200));
      send(response,201,{ok:true,id:stored.id,status:'received'});
    }catch(error){send(response,error.message==='payload-too-large'?413:400,{ok:false,error:error.message});}
    return;
  }
  send(response,404,{ok:false,error:'not-found'});
});

server.listen(port,'0.0.0.0',()=>{
  console.log('Serveur Déclic prêt sur le port '+port);
  console.log('POST /api/merchant-proposals');
  console.log('POST /api/card-orders');
  console.log('Tableau de suivi : http://localhost:'+port);
});
