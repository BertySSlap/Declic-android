# Déclic Usager 1.5.6 / serveur V11.9

- Une carte Déclic commandée devient un Point Déclic personnel sélectionnable dans le planning hebdomadaire.
- « Ma carte Déclic » apparaît en premier dans chaque liste de Point du jour, avant Surprise et les commerces.
- Le planning envoie `personal:<user_id>` au serveur lorsqu'une carte personnelle est choisie.
- « Déjà validé aujourd'hui » n'est affiché qu'après confirmation d'une validation réellement enregistrée côté serveur.
- Un QR refusé (mauvais Point, mauvais jour, trop tard, aucun Point choisi) ne valide plus l'étape scan et laisse l'usager réessayer.
