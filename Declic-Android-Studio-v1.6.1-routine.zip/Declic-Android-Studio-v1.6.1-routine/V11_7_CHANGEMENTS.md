# Déclic Usager 1.5.4 / serveur V11.7

- Calendrier exemptions/jokers : jours réussis en couleur Déclic, oublis en orange.
- « Enregistrer » dans les informations personnelles ferme le bloc d'édition.
- Le type de Point n'est plus un champ du profil : le serveur reçoit le filtre réellement choisi dans l'onglet Carte.
- Changement d'e-mail : lien de confirmation prototype avant remplacement effectif.
- Changement de téléphone : code SMS prototype à 6 chiffres avant remplacement effectif.
- Vocabulaire « oubli » à la place de « échec » dans les écrans concernés.
- Enveloppes projet : frais de déblocage anticipé fixes à 5 %, non modifiables par l'usager.
- Les enveloppes créées apparaissent sous la Cagnotte Déclic bloquée dans le même langage visuel.
- Synchronisation serveur étendue : profil, ville, rituel, réveil, planning des Points, Carte, modes financiers, enveloppes, cagnotte, récompenses, jokers/exemptions et état brut de l'application.
- Commande de carte et génération du QR personnel reliées au serveur avec l'identité de l'usager.
