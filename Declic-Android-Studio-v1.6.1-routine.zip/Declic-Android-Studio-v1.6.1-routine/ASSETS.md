# Visuels de personnalisation 1.3.5

- `cable-tresse-prototype.png` : visuel de concept généré avec ImageGen, pas une photo fournisseur. Prompt de conception : photographie produit d'un fin câble métallique tressé en boucle, environ 150 mm, avec fermoir cylindrique moleté, finition argent, fond ivoire chaud, sans texte ni logo. L'image est identifiée comme générée dans l'interface.
- `notice-carte-declic.jpeg` : référence déjà présente dans le projet, inchangée. Les trois panneaux sont affichés par cadrage CSS aux séparations verticales x=405 et x=550 sur une image de 901 × 212 pixels.
- `card-icons.js` : premier dessin conservé ; dix-neuf nouveaux pictogrammes SVG au trait arrondi et cohérent, écrits pour ce prototype.
- `declic-logo.png` : recadrage mécanique du deuxième logo de la planche `Variations d’icônes DÉCLIC minimalistes(1).png` fournie par l'utilisateur ; utilisé par l'application usager et pour les icônes Android.
- `declic-commercant-logo.png` : copie redimensionnée de `Icône D Clic Commerçant Minimaliste(1).png` fournie par l'utilisateur ; utilisée dans l'espace professionnel, sans modification du dessin.
