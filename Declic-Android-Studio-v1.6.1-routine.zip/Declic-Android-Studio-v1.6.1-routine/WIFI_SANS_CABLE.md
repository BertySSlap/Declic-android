# Déclic Usager 1.5.3 — connexion Wi-Fi

Cette version peut retrouver automatiquement le serveur Déclic V11.9 sur le même réseau Wi-Fi.

- Aucun `adb reverse` n'est nécessaire en mode Wi-Fi.
- Lancez `START_SERVER_WIFI.bat` sur le PC.
- Le téléphone et le PC doivent être sur le même Wi-Fi / partage de connexion.
- L'app teste d'abord l'ancienne connexion USB/émulateur, puis recherche le serveur sur le sous-réseau local.
- L'adresse trouvée est mémorisée dans `declic.serverBase`.

Si la détection automatique ne trouve pas le PC, le bouton **Connexion serveur Wi-Fi** apparaît. Recopiez simplement l'adresse `http://...:8765` affichée par le serveur.
