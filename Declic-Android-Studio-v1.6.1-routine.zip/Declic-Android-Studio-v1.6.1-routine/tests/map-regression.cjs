/* Run with node tests/map-regression.cjs. Tests adapter logic, not browser rendering. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assets = path.join(__dirname, '../app/src/main/assets');
const html = fs.readFileSync(path.join(assets, 'index.html'), 'utf8');
const nodes = {};
function node(id) {
  return nodes[id] || (nodes[id] = {clientHeight: id === 'osmMap' ? 0 : 100,
    classList: {toggle() {}}, addEventListener(event, cb) { this[event] = cb; }});
}
const observed = {fits: 0, clears: 0, markers: [], mapCount: 0};
function layer(latlng, options) {
  return {latlng, options, addTo() {return this;}, setLatLng(v) {this.latlng=v;return this;},
    setRadius(v) {this.options.radius=v;return this;}, setStyle() {return this;},
    getBounds() {return {centre: this.latlng, radius: this.options.radius};},
    on(event, cb) {this[event]=cb;return this;}, setIcon() {return this;}, setZIndexOffset() {return this;}};
}
const L = {
  map() {observed.mapCount++; return {setView() {return this;},
    attributionControl: {setPrefix() {}}, invalidateSize() {},
    fitBounds(bounds) {observed.fits++;observed.bounds=bounds;}};},
  control: {zoom() {return {addTo() {}};}, scale() {return {addTo() {}};}},
  tileLayer(url, options) {observed.tileUrl=url;observed.attribution=options.attribution;return layer(null, options);},
  markerClusterGroup(options) {observed.clusterOptions=options;return {
    addTo() {return this;}, clearLayers() {observed.clears++;observed.markers=[];},
    addLayer(marker) {observed.markers.push(marker);}};},
  circle(latlng, options) {observed.circle=layer(latlng,options);return observed.circle;},
  circleMarker(latlng, options) {observed.origin=layer(latlng,options);return observed.origin;},
  marker(latlng, options) {return layer(latlng,options);}, divIcon(options) {return options;}
};
const context = {window: {L, addEventListener() {}}, L,
  document: {documentElement: {}, getElementById: node, createElement() {return {outerHTML: '<span></span>'};}},
  getComputedStyle() {return {getPropertyValue() {return '#2b7e59';}};},setTimeout,clearTimeout};
vm.runInNewContext(fs.readFileSync(path.join(assets, 'declic-map.js'), 'utf8'), context);
const adapter = context.window.DeclicMap;
const places = [{id:'cafe',lat:48.5801,lon:7.7451,icon:'☕',name:'Test Café'},
  {id:'bakery',lat:48.5802,lon:7.7452,icon:'🥐',name:'Test Boulangerie'}];
let selected,details;
let state = {center:{lat:48.5812,lon:7.746},radius:750,places,selected:'cafe',onSelect:id=>{selected=id;},onLongPress:id=>{details=id;}};
adapter.update(state);
assert.equal(observed.mapCount,0,'No tile requests from the hidden home screen');
node('osmMap').clientHeight=330; adapter.show();
assert.equal(observed.mapCount,1);
assert.equal(observed.circle.options.radius,750);
assert.deepEqual(Array.from(observed.origin.latlng),[48.5812,7.746]);
assert.deepEqual(Array.from(observed.markers[0].latlng),[48.5801,7.7451]);
assert.equal(observed.bounds.radius,750);
assert.match(observed.attribution,/openstreetmap.org\/copyright/);
assert.equal(observed.tileUrl,'https://tile.openstreetmap.org/{z}/{x}/{y}.png');
const fits=observed.fits, clears=observed.clears;
observed.markers[1].click(); assert.equal(selected,'bakery');
observed.markers[0].contextmenu({originalEvent:{preventDefault(){}}});assert.equal(details,'cafe');
state={...state,selected:'bakery'}; adapter.update(state);
assert.equal(observed.fits,fits,'Selecting a point must preserve map pan/zoom');
assert.equal(observed.clears,clears,'Selecting a point must preserve expanded clusters');
state={...state,places:places.slice(0,1)};adapter.update(state);
assert.equal(observed.markers.length,1);
assert.equal(observed.fits,fits,'Category filtering must not jump to another location');
state={...state,radius:2000};adapter.update(state);
assert.equal(observed.circle.options.radius,2000);
assert.equal(observed.fits,fits+1);
state={...state,center:{lat:48.57,lon:7.755},places:[]};adapter.update(state);
assert.deepEqual(Array.from(observed.origin.latlng),[48.57,7.755]);
assert.equal(observed.markers.length,0,'Empty search must clear old markers');
adapter.recenter();assert.equal(observed.bounds.radius,2000);
assert.equal(observed.clusterOptions.spiderfyOnMaxZoom,true,'Overlapping locations must remain selectable');

const geography = vm.createContext({Math,Number,radiusSlider:{value:'750'},
  mapCenter:{lat:48.5812,lon:7.746},activeCategory:'all',placeData:[]});
vm.runInContext(html.slice(html.indexOf('function distanceMeters('),html.indexOf('function renderSelectedPlace(')),geography);
geography.placeData=[
  {id:'inside',lat:48.5812,lon:7.746,category:'cafe'},
  {id:'outside',lat:48.6000,lon:7.746,category:'bakery'}];
assert.equal(geography.distanceMeters(48.5812,7.746,48.5812,7.746),0);
assert.ok(Math.abs(geography.distanceMeters(0,0,0,1)-111195)<10);
assert.equal(geography.visiblePlaces().length,1);
geography.radiusSlider.value='250';assert.equal(geography.visiblePlaces().length,1);
geography.activeCategory='bakery';assert.equal(geography.visiblePlaces().length,0);
geography.mapCenter={lat:48.6000,lon:7.746};assert.equal(geography.visiblePlaces()[0].id,'outside');
geography.mapCenter=null;assert.equal(geography.visiblePlaces().length,0);
assert.ok(!html.includes('googleMapFrame'),'No independent Google iframe overlay');
assert.ok(html.includes("if(id==='map' && window.DeclicMap)"),'Navigation remeasures the map');
assert.ok(!html.includes("setMapOrigin(address,address,'manual',null)"),'Failed address preserves previous location');
assert.ok(html.includes("if(activeCategory==='park') return []"),'Green spaces never appear as partner map markers');
assert.ok(html.includes('hasOffer:true'),'Prototype includes partner offers');
assert.ok(fs.readFileSync(path.join(assets,'declic-map.js'),'utf8').includes("place.hasOffer ? ' has-offer'"),'Offer markers receive the orange-dot class');
assert.ok(fs.readFileSync(path.join(assets,'declic-map.js'),'utf8').includes("state.onLongPress(place.id)"),'Long press opens point details');
console.log('PASS: geographic layers, radius, filters, selection, clustering, navigation and empty results.');
console.log('Browser rendering, network tiles and Android touch/GPS still require a device test.');
