const assert=require('node:assert/strict');
const payment=require('../app/src/main/assets/payment-core.js');

assert.equal(payment.lastFour('4242 4242 4242 4242'),'4242');
assert.equal(payment.lastFour('12'),'');
assert.equal(payment.luhnValid('4242 4242 4242 4242'),true);
assert.equal(payment.luhnValid('4111 1111 1111 4827'),false);

const invalidMinimum=payment.validate({
  cardholder:'Melvin Test',cardNumber:'4242424242424242',potTarget:4,
  autoTopup:false,threshold:2,day:5,expectedCardholder:'Melvin Test'
});
assert.equal(invalidMinimum.ok,false);
assert.equal(invalidMinimum.field,'potTarget');

const invalidThreshold=payment.validate({
  cardholder:'Melvin Test',cardNumber:'4242424242424242',potTarget:40,
  autoTopup:true,threshold:40,day:5,expectedCardholder:'Melvin Test'
});
assert.equal(invalidThreshold.ok,false);
assert.equal(invalidThreshold.field,'threshold');

const wrongHolder=payment.validate({
  cardholder:'Autre Personne',cardNumber:'4242424242424242',potTarget:40,
  autoTopup:true,threshold:10,day:5,expectedCardholder:'Melvin Test'
});
assert.equal(wrongHolder.ok,false);
assert.equal(wrongHolder.field,'cardholder');

const valid=payment.validate({
  cardholder:' Melvin Test ',cardNumber:'4242 4242 4242 4242',potTarget:40,
  autoTopup:true,threshold:10,day:5,expectedCardholder:'Test Melvin'
});
assert.equal(valid.ok,true);
assert.deepEqual(valid.value,{
  cardholder:'Melvin Test',last4:'4242',potTarget:40,threshold:10
});
assert(!JSON.stringify(valid.value).includes('4242424242424242'),'full card number must never be stored');
assert.equal(Object.hasOwn(valid.value,'day'),false,'monthly top-up day is removed');
assert.equal(Object.hasOwn(valid.value,'autoTopup'),false,'automatic refill is no longer an optional setting');
console.log('PASS: payment validates Luhn, holder, target/threshold and keeps refill threshold-based.');
