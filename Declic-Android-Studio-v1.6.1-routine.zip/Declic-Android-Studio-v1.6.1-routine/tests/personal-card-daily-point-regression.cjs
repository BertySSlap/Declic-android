const fs=require('fs');
const path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const required=[
  "const PERSONAL_CARD_POINT='__personal_card__'",
  "name:'Ma carte Déclic'",
  "D Ma carte Déclic",
  "placeId===PERSONAL_CARD_POINT",
  "return 'personal:'+USER_ID",
  'successfulServerCheckinToday',
  "error.data&&error.data.validated",
  "daySteps.scan=false",
  "declic.personalCardOrderPlaced",
  "activatePersonalCardPlannerAfterOrder",
  "clearFalseLocalValidationForDate",
  "if(hasRewardedCheckInToday())clearFalseLocalValidationForDate(result.server_date||'')"
];
for(const token of required){if(!html.includes(token))throw new Error('missing V11.9.1 personal-card/validation token: '+token)}
console.log('PASS: ordered personal card is immediately selectable per day and only successful server check-ins can lock the day.');
