const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const http=require('node:http');
const {spawn}=require('node:child_process');

const temp=fs.mkdtempSync(path.join(os.tmpdir(),'declic-proposals-'));
const dataFile=path.join(temp,'proposals.json');
const orderDataFile=path.join(temp,'orders.json');
const port=18123+Math.floor(Math.random()*1000);
const server=spawn(process.execPath,[path.join(__dirname,'../prototype-server/server.js')],{
  env:{...process.env,DECLIC_SERVER_PORT:String(port),DECLIC_DATA_FILE:dataFile,DECLIC_ORDER_DATA_FILE:orderDataFile},stdio:['ignore','pipe','inherit']
});

function request(method,route,body){
  return new Promise((resolve,reject)=>{
    const req=http.request({hostname:'127.0.0.1',port,path:route,method,headers:{'Content-Type':'application/json'}},response=>{
      let text='';response.on('data',chunk=>text+=chunk);response.on('end',()=>resolve({status:response.statusCode,body:JSON.parse(text||'{}')}));
    });
    req.on('error',reject);if(body)req.write(JSON.stringify(body));req.end();
  });
}

(async()=>{
  await new Promise((resolve,reject)=>{
    const timeout=setTimeout(()=>reject(new Error('server-timeout')),5000);
    server.stdout.on('data',chunk=>{if(String(chunk).includes('Serveur Déclic prêt')){clearTimeout(timeout);resolve();}});
    server.on('exit',code=>reject(new Error('server-exit-'+code)));
  });
  const created=await request('POST','/api/merchant-proposals',{id:'proposal-test',name:'Café test',address:'1 rue Test'});
  assert.equal(created.status,201);assert.equal(created.body.id,'proposal-test');
  const listed=await request('GET','/api/merchant-proposals');
  assert.equal(listed.status,200);assert.equal(listed.body.proposals.length,1);assert.equal(listed.body.proposals[0].status,'reçu');
  const orderCreated=await request('POST','/api/card-orders',{id:'card-order-test',displayName:'M. Test',design:{visuals:['icon:route']},visualNames:['Paysage Déclic'],amount:10});
  assert.equal(orderCreated.status,201);assert.equal(orderCreated.body.id,'card-order-test');
  const orders=await request('GET','/api/card-orders');
  assert.equal(orders.status,200);assert.equal(orders.body.orders.length,1);assert.equal(orders.body.orders[0].status,'reçu');
  server.kill();fs.rmSync(temp,{recursive:true,force:true});
  console.log('PASS: prototype server receives and persists merchant proposals and real-time card orders.');
})().catch(error=>{server.kill();fs.rmSync(temp,{recursive:true,force:true});console.error(error);process.exit(1);});
