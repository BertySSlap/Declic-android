const path=require('node:path');
const fs=require('node:fs');
const assert=require('node:assert/strict');
const {chromium}=require('playwright');

(async()=>{
  const executable=chromium.executablePath();
  if(!fs.existsSync(executable)){
    console.log('SKIP: Playwright browser binary is not installed; core and HTML regressions still run.');
    return;
  }
  const browser=await chromium.launch({headless:true});
  const page=await browser.newPage();
  await page.goto('file://'+path.resolve(__dirname,'../app/src/main/assets/index.html'));
  await page.evaluate(()=>localStorage.clear());
  await page.reload();

  await page.click('#finishOnboardingBtn');
  assert.equal(await page.locator('#onboardingFirstName.input-invalid').count(),1);
  assert.equal(await page.locator('#onboardingLastName.input-invalid').count(),1);
  assert.equal(await page.locator('#onboardingEmail.input-invalid').count(),1);

  await page.fill('#onboardingFirstName','Melvin');
  await page.fill('#onboardingLastName','Test');
  await page.fill('#onboardingEmail','melvin@example.fr');
  await page.click('#sendVerificationEmailBtn');
  await page.click('#finishOnboardingBtn');
  assert.equal(await page.locator('#onboardingEmail.input-invalid').count(),1,'account remains blocked before link click');
  await page.click('#confirmVerificationEmailBtn');
  await page.click('#finishOnboardingBtn');
  assert.equal(await page.locator('#onboarding.hidden').count(),1);
  const account=await page.evaluate(()=>JSON.parse(localStorage.getItem('declic.account')));
  assert.equal(account.emailVerified,true);

  await page.evaluate(()=>showOnboarding());
  await page.click('#onboardingFundChoice');
  await page.fill('#onboardingCardholder','Autre Personne');
  await page.fill('#onboardingCardNumber','4111111111114827');
  await page.fill('#onboardingPotTarget','4');
  await page.fill('#onboardingTopupThreshold','4');
  await page.click('#finishOnboardingBtn');
  assert((await page.locator('#onboardingFundingSettings .input-invalid').count())>=3);

  await page.fill('#onboardingCardholder','Melvin Test');
  await page.fill('#onboardingCardNumber','4242424242424242');
  await page.fill('#onboardingPotTarget','40');
  await page.fill('#onboardingTopupThreshold','10');
  await page.click('#finishOnboardingBtn');
  const payment=await page.evaluate(()=>JSON.parse(localStorage.getItem('declic.paymentSettings')));
  assert.equal(payment.last4,'4242');
  assert.equal(JSON.stringify(payment).includes('4242424242424242'),false);

  await page.evaluate(()=>go('settings'));
  assert.equal(await page.locator('#walkValidationToggle.on').count(),0,'walk validation defaults to off');
  await page.click('#simulateDeclicSuccessBtn');
  await page.click('#simulateDeclicFailureBtn');
  const result=await page.evaluate(()=>({
    rewards:JSON.parse(localStorage.getItem('declic.rewardsState')),
    wallet:JSON.parse(localStorage.getItem('declic.walletState')),
    rate:document.getElementById('successRateValue').textContent
  }));
  assert.equal(result.rewards.totalValidations,1);
  assert.equal(result.rewards.totalFailures,1);
  assert.equal(result.rewards.points,4);
  assert.equal(result.wallet.available,30);
  assert.equal(result.wallet.donated,10);
  assert.equal(result.rate,'50 %');

  await browser.close();
  console.log('PASS: onboarding errors, email link gate, payment rules, walk default and success/failure buttons work in-browser.');
})().catch(error=>{console.error(error);process.exit(1);});
