const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const html=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
const start=html.indexOf('function localDayKey('),end=html.indexOf('function setScanState(',start);
assert(start>0&&end>start);
const storage=new Map(),context={
  localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value)},
  activeDays:new Set([1,2,3,4,5]),document:{getElementById:()=>null},console,Date
};
vm.createContext(context);vm.runInContext(html.slice(start,end),context);
const point={id:'cafe-test',name:'Café test'};
const first=vm.runInContext('awardRewardedCheckIn('+JSON.stringify(point)+')',context);
assert.equal(first.duplicate,false);assert.equal(first.points,4);
const second=vm.runInContext('awardRewardedCheckIn('+JSON.stringify({id:'autre',name:'Autre lieu'})+')',context);
assert.equal(second.duplicate,true);assert.equal(second.points,0);
const state=JSON.parse(storage.get('declic.rewardsState'));
assert.equal(state.totalValidations,1);assert.equal(state.visitedPartnerIds.length,1);assert.equal(state.points,4);
const missed=vm.runInContext('recordMissedDeclic(new Date(2026,8,14,12))',context);
assert.equal(missed.totalFailures,1);assert.equal(missed.currentStreak,0);assert.equal(missed.points,4);
for(const [before,bonus] of [[4,5],[13,15],[29,30]]){
  const yesterday=new Date();yesterday.setDate(yesterday.getDate()-1);
  context.activeDays=new Set([0,1,2,3,4,5,6]);
  storage.set('declic.rewardsState',JSON.stringify({points:0,currentStreak:before,bestStreak:before,lastRewardDate:context.localDayKey(yesterday),totalValidations:before,totalBonuses:0,visitedPartnerIds:[point.id],history:[]}));
  const result=vm.runInContext('awardRewardedCheckIn('+JSON.stringify(point)+')',context);
  assert.equal(result.points,1+bonus);assert.equal(result.state.currentStreak,before+1);
}
context.activeDays=new Set([1,2,3,4,5]);
assert.equal(vm.runInContext("hasMissedActiveDay('2026-09-04','2026-09-07')",context),false,'weekend pauses preserve streak');
assert.equal(vm.runInContext("hasMissedActiveDay('2026-09-04','2026-09-08')",context),true,'missed Monday breaks streak');
storage.delete('declic.rewardsState');context.activeDays=new Set([0,1,2,3,4,5,6]);
const promoPoint={id:'promo',name:'Café promo',offerRules:[{type:'welcome',label:'−10 % de bienvenue'},{type:'loyalty',every:5,label:'Café offert'}]};
let promoResult;
for(let day=1;day<=5;day++)promoResult=vm.runInContext('awardRewardedCheckIn('+JSON.stringify(promoPoint)+',new Date(2026,8,'+day+',12),true)',context);
assert.equal(promoResult.visitCount,5);assert.equal(promoResult.offers.length,1);assert.equal(promoResult.offers[0].label,'Café offert');
const promoState=JSON.parse(storage.get('declic.rewardsState'));
assert.equal(promoState.visitCounts.promo,5);assert.equal(promoState.offerHistory.length,2,'welcome and fifth-visit offers are stored');
console.log('PASS: one rewarded check-in/day, pause-aware streaks, merchant visit counts and configured offers.');
