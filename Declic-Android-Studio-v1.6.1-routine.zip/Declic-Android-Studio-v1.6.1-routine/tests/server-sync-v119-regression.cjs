const fs=require('fs');
const path=require('path');
const html=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/index.html'),'utf8');
const required=[
  "appVersion:'1.6.1-routine'",
  'calendarOutcomeForKey',
  'window.DeclicCalendarServerOutcomes',
  '.cal-day.success{background:var(--green)',
  '.cal-day.failure{background:var(--orange)',
  'scheduleUserServerPush',
  "document.addEventListener('change',scheduleUserServerPush,true)",
  'comparableUserState',
  'refreshServerUserSnapshot',
  "events.some(e=>e.entity_type==='checkin'||e.entity_type==='advantage'||e.entity_type==='form'||e.entity_type==='order')"
];
for(const token of required){if(!html.includes(token))throw new Error('missing V11.9 token: '+token)}
console.log('PASS: V11.9 user live sync and calendar success/omission colors are wired.');
