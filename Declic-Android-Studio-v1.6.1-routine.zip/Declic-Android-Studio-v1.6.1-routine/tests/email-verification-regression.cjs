const assert=require('node:assert/strict');
const email=require('../app/src/main/assets/email-verification-core.js');

assert.equal(email.normalizeEmail('  Melvin@Example.FR '),'melvin@example.fr');
assert.equal(email.isValidEmail('melvin@example.fr'),true);
assert.equal(email.isValidEmail('melvin@'),false);

const now=Date.UTC(2026,8,13,12,0,0);
const request=email.createRequest('Melvin@Example.FR',now,'fixed-test-nonce');
assert(request);
assert.equal(request.email,'melvin@example.fr');
assert.equal(email.verify(request,request.token,'melvin@example.fr',now+29*60*1000),true);
assert.equal(email.verify(request,'wrong-token','melvin@example.fr',now),false);
assert.equal(email.verify(request,request.token,'other@example.fr',now),false);
assert.equal(email.verify(request,request.token,'melvin@example.fr',now+31*60*1000),false);
console.log('PASS: verification link is bound to the normalized email and expires after 30 minutes.');
