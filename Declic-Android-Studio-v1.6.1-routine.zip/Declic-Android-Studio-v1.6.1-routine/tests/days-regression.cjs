const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
const buttons=Array.from({length:7},(_,day)=>({dataset:{day},classes:{},classList:{toggle(k,v){buttons[day].classes[k]=v;}},setAttribute(){},addEventListener(type,fn){this.click=fn;}}));
const stored={},grid={innerHTML:'',querySelectorAll(){return [];}};
const context={document:{querySelectorAll:()=>buttons,getElementById:()=>({})},activeDays:new Set([1,2,3,4,5]),dayNames:['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'],localStorage:{setItem:(k,v)=>stored[k]=v},weeklyPointGrid:grid,weeklyAssignments:{3:'__surprise__',6:'test'},placesInRadius:()=>[{id:'test',name:'Lieu test',icon:'x'}],surpriseEnabled:false,SURPRISE_POINT:'__surprise__',dayUsesSurprise:day=>context.surpriseEnabled||context.weeklyAssignments[day]==='__surprise__',currentDayUsesSurprise:()=>false,placeData:[],applyHomePoint(){},chooseSurprisePoint(){},renderDailyProgress(){},renderCalendar(){},Date};
vm.createContext(context);
const planner=html.slice(html.indexOf('function renderWeeklyPointPlanner(){'),html.indexOf('\nfunction ',html.indexOf('function renderWeeklyPointPlanner(){')+10));
vm.runInContext(planner,context);
vm.runInContext(html.slice(html.indexOf('// Jours actifs'),html.indexOf('// Exemptions + joker mensuel')),context);
vm.runInContext('renderActiveDays()',context);
assert(buttons[6].classes['day-off']);
buttons[6].click();
assert(context.activeDays.has(6));assert(buttons[6].classes.on);
assert(grid.innerHTML.includes('data-toggle-day="6" aria-pressed="true"'));
assert(grid.innerHTML.includes('✦ Point Déclic surprise'));
assert(grid.innerHTML.includes('data-weekly-day="3"'));
context.surpriseEnabled=true;vm.runInContext('renderWeeklyPointPlanner()',context);
assert.equal((grid.innerHTML.match(/<select[^>]*disabled/g)||[]).length,7);
context.surpriseEnabled=false;
vm.runInContext('toggleActiveDay(6)',context);
assert(!context.activeDays.has(6));assert(buttons[6].classes['day-off']);
assert(grid.innerHTML.includes('data-toggle-day="6" aria-pressed="false"'));
assert(grid.innerHTML.includes('data-weekly-day="6" disabled'));
assert.equal(context.weeklyAssignments[6],'test');
assert(!JSON.parse(stored['declic.activeDays']).includes(6));

const gpsStore={};
const gpsContext={
  mapOriginMode:'gps',activeDaysWereStored:false,weeklyPointsWereStored:false,
  SURPRISE_POINT:'__surprise__',
  localStorage:{getItem:key=>gpsStore[key]||null,setItem:(key,value)=>{gpsStore[key]=value;}},
  placesInRadius:()=>[
    {id:'second',name:'Deuxième',distance:200},
    {id:'closest',name:'Plus proche',distance:100},
    {id:'third',name:'Troisième',distance:300}
  ],
  computedDistance:place=>place.distance,weeklyAssignments:{},activeDays:new Set(),
  chosenPlaceId:'',selectedPlaceId:'',Math,Date,JSON,
  renderNearby(){},renderActiveDays(){},renderDailyProgress(){},applyHomePoint(){},placeData:[]
};
vm.createContext(gpsContext);
const initStart=html.indexOf('function initializeWeeklyPointsFromGps(){');
const initEnd=html.indexOf('\nfunction applyHomePoint(',initStart);
vm.runInContext(html.slice(initStart,initEnd),gpsContext);
assert.equal(vm.runInContext('initializeWeeklyPointsFromGps()',gpsContext),true);
assert.equal(gpsContext.weeklyAssignments[1],'closest');
assert.equal(gpsContext.weeklyAssignments[2],'second');
assert.equal(gpsContext.weeklyAssignments[3],'closest');
assert.equal(gpsContext.weeklyAssignments[4],'__surprise__');
assert.equal(gpsContext.weeklyAssignments[5],'second');
assert.equal(gpsContext.weeklyAssignments[6],'');
assert.equal(gpsContext.weeklyAssignments[0],'');
assert.deepEqual(Array.from(gpsContext.activeDays).sort(),[1,2,3,4,5]);
assert.equal(vm.runInContext('initializeWeeklyPointsFromGps()',gpsContext),false,'first-use defaults are not applied twice');
console.log('PASS: days synchronized, per-day surprise listed first, global surprise locks all active selections, pause and persistence retained.');
