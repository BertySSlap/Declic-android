/* Model/interaction tests with a minimal DOM double, not a browser-rendering test. */
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const root=path.join(__dirname,'../app/src/main/assets'),core=require(path.join(root,'card-editor-core.js'));
assert.equal(core.normalize('front-qr',{scale:.1}).scale,1);
assert.equal(core.normalize('back-qr',{scale:2}).scale,2);
assert.equal(core.normalize('name',{scale:3}).scale,1);
assert.equal(core.normalize('import-0',{scale:.5,rotation:45}).rotation,45);
assert.equal(core.deltaAngle(170,-170),20);
assert.equal(core.deltaAngle(-170,170),-20);
assert.equal(core.nearest([98],[100],4).delta,2);
assert.equal(core.nearest([90],[100],4),null);
const all=[],byId={};
class El {
  constructor(tag='div',id=''){
    this.tagName=tag;this.id=id;this.dataset={};this.style={};this.events={};this.children=[];this.value='';this._text='';this.parent=null;
    this._classes=new Set();this.classList={add:(x)=>this._classes.add(x),remove:(x)=>this._classes.delete(x),contains:x=>this._classes.has(x),toggle:(x,on)=>{if(on===undefined)on=!this._classes.has(x);on?this._classes.add(x):this._classes.delete(x);return on;}};
    all.push(this);if(id)byId[id]=this;
  }
  set className(v){this._classes=new Set(v.split(/\s+/));}get className(){return [...this._classes].join(' ');}
  set textContent(v){this._text=v;this.children=[];}get textContent(){return this._text+this.children.map(c=>c.textContent).join('');}
  set innerHTML(v){this.html=v;this.children=[];}get outerHTML(){return '<span></span>';}
  appendChild(el){el.parent=this;this.children.push(el);return el;}
  setAttribute(n,v){this[n]=v;}addEventListener(t,cb){(this.events[t]||(this.events[t]=[])).push(cb);}
  setPointerCapture(){}contains(el){return el===this||this.children.some(c=>c.contains(el));}
  matches(s){return s==='[data-card-element]'?!!this.dataset.cardElement:s==='[data-visual]'?!!this.dataset.visual:s[0]==='#'?this.id===s.slice(1):s[0]==='.'?this._classes.has(s.slice(1)):s===this.tagName;}
  closest(s){let e=this;while(e){if(e.matches(s))return e;e=e.parent;}return null;}
  querySelectorAll(s){return all.filter(el=>el!==this&&this.contains(el)&&s.split(',').some(part=>el.matches(part)));}
  get clientWidth(){return this.classList.contains('hidden')?0:(this.id==='customCardFront'||this.id==='customCardBack'?400:this.offsetWidth);}
  get clientHeight(){return this.classList.contains('hidden')?0:(this.id==='customCardFront'||this.id==='customCardBack'?288:this.offsetHeight);}
  get offsetWidth(){return /qr/.test(this.dataset.cardElement||'')?100:this.dataset.cardElement==='art'?270:100;}
  get offsetHeight(){return /qr/.test(this.dataset.cardElement||'')?100:40;}
  getBoundingClientRect(){
    if(this.matches('.custom-card-preview'))return {left:0,top:0,right:400,bottom:288,width:400,height:288};
    const t=this.style.transform||'',m=/translate\(([-\d.]+)px,([-\d.]+)px\) rotate\(([-\d.]+)deg\) scale\(([-\d.]+)\)/.exec(t);
    const x=m?+m[1]:0,y=m?+m[2]:0,rotation=m?+m[3]:0,scale=m?+m[4]:1;
    const b=core.rotatedSize(this.offsetWidth*scale,this.offsetHeight*scale,rotation);
    const left=50+x+(this.offsetWidth-b.width)/2,top=60+y+(this.offsetHeight-b.height)/2;
    return {left,top,right:left+b.width,bottom:top+b.height,width:b.width,height:b.height};
  }
}
const body=new El('body'),front=new El('div','customCardFront'),back=new El('div','customCardBack');
front.className=back.className='custom-card-preview';body.appendChild(front);body.appendChild(back);
for(const [id,key] of [['customCardArtPreview','visual-0'],['customCardNamePreview','name'],['customCardSloganPreview','slogan'],['frontQr','front-qr']]){
  const el=new El('div',id);el.dataset.cardElement=key;front.appendChild(el);
}
const backQr=new El('div','backQr');backQr.dataset.cardElement='back-qr';back.appendChild(backQr);
for(const id of ['customCardName','customCardSlogan','finishCardEdit','undoCardEdit','cardEditHelp','customSvgUpload','importedSvgList','visualLibrary','openVisualLibrary','iconLibraryGrid','closeVisualLibrary','resetCardLayout','visualSelectionStatus'])body.appendChild(new El('div',id));
byId.customCardName.value='Nom test';byId.customCardSlogan.value='Rituel ☀';byId.visualLibrary.classList.add('hidden');
const store=new Map(),timers=[];
class FakeDomParser{parseFromString(text){const root={localName:'svg',_text:text,attributes:[],querySelectorAll(){return[];},hasAttribute(name){return name==='viewBox';},setAttribute(){}};return{documentElement:root,querySelector(){return null;}};}}
class FakeSerializer{serializeToString(root){return root._text;}}
class FakeFileReader{readAsText(file){this.result=file.content;this.onload();}}
const context={window:{DeclicEditorCore:core,addEventListener(){}},document:{body,querySelectorAll:s=>all.filter(el=>s.split(',').some(part=>el.matches(part))),getElementById:id=>byId[id],createElement:tag=>new El(tag),createElementNS:(ns,tag)=>new El(tag),createTextNode:text=>{const el=new El('#text');el.textContent=text;return el;}},
  localStorage:{getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v)},toast(){},setTimeout:cb=>{timers.push(cb);return timers.length;},clearTimeout(){},DOMParser:FakeDomParser,XMLSerializer:FakeSerializer,FileReader:FakeFileReader,visualContents:{route:'<svg viewBox="0 0 154 35"><path d="M0 30h69"/></svg>'},console};
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(root,'card-icons.js'),'utf8'),context);
assert.equal(context.window.DeclicIcons.length,20);assert.equal(new Set(context.window.DeclicIcons.map(i=>i.id)).size,20);
vm.runInContext(fs.readFileSync(path.join(root,'card-editor-v3.js'),'utf8'),context);
async function fire(el,type,args={}){for(const cb of el.events[type]||[])await cb({target:el,preventDefault(){},...args});}
const layout=()=>JSON.parse(store.get('declic.cardLayout'));
const qr=byId.frontQr;
(async()=>{
  await fire(front,'pointerdown',{target:qr,pointerId:1,clientX:80,clientY:90});timers.pop()();
  await fire(front,'pointerdown',{target:qr,pointerId:2,clientX:180,clientY:90});
  await fire(front,'pointermove',{target:qr,pointerId:2,clientX:80,clientY:250});
  await fire(front,'pointerup',{pointerId:2});await fire(front,'pointerup',{pointerId:1});
  assert.equal(Math.round(layout()['front-qr'].rotation),90);assert.ok(layout()['front-qr'].scale>1);
  await fire(byId.undoCardEdit,'click');assert.equal(layout()['front-qr'].rotation,0);assert.equal(layout()['front-qr'].scale,1);
  await fire(front,'pointerdown',{target:qr,pointerId:3,clientX:80,clientY:90});timers.pop()();
  await fire(front,'pointerdown',{target:qr,pointerId:4,clientX:180,clientY:90});
  await fire(front,'pointermove',{target:qr,pointerId:4,clientX:85,clientY:90});
  await fire(front,'pointerup',{pointerId:4});await fire(front,'pointerup',{pointerId:3});assert.equal(layout()['front-qr'].scale,1);
  await fire(byId.openVisualLibrary,'click');assert.equal(byId.visualLibrary.classList.contains('hidden'),false);
  assert.equal(byId.iconLibraryGrid.children.length,20);
  const sun=byId.iconLibraryGrid.children.find(b=>b.dataset.visual==='sun'),leaf=byId.iconLibraryGrid.children.find(b=>b.dataset.visual==='leaf'),coffee=byId.iconLibraryGrid.children.find(b=>b.dataset.visual==='coffee');
  await fire(sun,'click');await fire(leaf,'click');
  assert.deepEqual(JSON.parse(store.get('declic.cardDesign')).visuals,['icon:route','icon:sun','icon:leaf']);
  await fire(coffee,'click');assert.equal(JSON.parse(store.get('declic.cardDesign')).visuals.length,3);
  await fire(byId.undoCardEdit,'click');assert.deepEqual(JSON.parse(store.get('declic.cardDesign')).visuals,['icon:route','icon:sun']);
  const emoji=byId.customCardSloganPreview.children.find(el=>el.classList.contains('mono-emoji'));assert.ok(emoji);
  await fire(byId.customCardName,'focus');byId.customCardName.value='Nouveau nom';await fire(byId.customCardName,'input');
  await fire(byId.undoCardEdit,'click');assert.equal(byId.customCardName.value,'Nom test');
  byId.customSvgUpload.files=[{name:'1.svg'},{name:'2.svg'},{name:'3.svg'},{name:'4.svg'}];await fire(byId.customSvgUpload,'change');
  assert.equal(JSON.parse(store.get('declic.cardDesign')).imports.filter(Boolean).length,0);
  byId.customSvgUpload.files=[1,2,3].map(i=>({name:i+'.svg',size:100,content:'<svg viewBox="0 0 10 10"><path d="M0 0h'+i+'"/></svg>'}));await fire(byId.customSvgUpload,'change');
  let saved=JSON.parse(store.get('declic.cardDesign'));assert.equal(saved.imports.length,3);assert.equal(saved.visuals.length,3);
  const firstDelete=byId.importedSvgList.children[0].children[1];await fire(firstDelete,'click');saved=JSON.parse(store.get('declic.cardDesign'));
  assert.equal(saved.imports.length,2);assert.equal(saved.imports.some(item=>item.name==='1.svg'),false);
  console.log('PASS: Paysage Déclic default, 3 simultaneous visuals maximum, 20 icons, rotation/scaling, QR minimum, undo, emoji wrappers and SVG import limit.');
})().catch(error=>{console.error(error);process.exitCode=1;});
