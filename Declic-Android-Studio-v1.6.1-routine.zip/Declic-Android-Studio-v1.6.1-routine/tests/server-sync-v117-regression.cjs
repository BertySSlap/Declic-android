const fs=require('fs'),assert=require('assert');
const html=fs.readFileSync(__dirname+'/../app/src/main/assets/index.html','utf8');
const wallet=fs.readFileSync(__dirname+'/../app/src/main/assets/wallet-core.js','utf8');

assert(html.includes('data-day="0">D</button>'),'Sunday stays encoded as 0 internally in the Android app');
for(const token of [
  'profileInitial(name)','renderProfileIdentity(account=savedAccount())','account.displayName=name','account.city=city',
  'map_filter_category:','map_filter_label:','amount_per_omission:','savings_projects_json:',
  'donation_association:','donation_payment_frequency:','savings_lock_months:','savings_destination:',
  'alarm_linked:','validation_delay_minutes:','last_wake_time:','last_wake_detected_at:',
  'exemptions_json:','joker_calendar_json:','weekly_point_plan_json:','weekly_point_plan_display_json:',
  '/email/request','/email/confirm','/phone/request','/phone/confirm','/api/card-orders','/api/personal-cards/'
]) assert(html.includes(token),'missing V11.7 user sync token '+token);
assert(!html.includes('id="profilePreferredPointSelect"'),'preferred Point type must not be a profile preference');
assert(html.includes("profileEditCard.classList.add('hidden')"),'saving personal information must close the edit card');
assert(html.includes('unlockFeePercent:5'),'project envelope early unlock fee must be fixed at 5%');
assert(wallet.includes('unlockFeePercent:5'),'wallet core must normalize project fee to 5%');
assert(html.includes('projectPotCards'),'created project envelopes must render below the main pot');
assert(html.includes(".cal-day.success") && html.includes(".cal-day.failure"),'calendar must expose success and omission states');
console.log('PASS: V11.7 user sync, verification, Map filter, fixed project fee, calendar and card/QR server wiring.');
