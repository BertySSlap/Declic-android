# Déclic — projet Android Studio

Application Android `com.declic.app`, version `1.4.6`, avec scanner QR réel, carte OpenStreetMap, Points Déclic filtrés par rayon, planning hebdomadaire, carte personnalisable, QR noirs sans fond, page promotionnelle du QR et onboarding avec choix de cagnotte.

## Cagnotte, projets et promotions 1.4.6

- Le jour mensuel et l’interrupteur de remplissage ont été retirés : une cagnotte financée revient automatiquement à sa cible dès que son solde atteint le seuil choisi.
- Un montant par oubli supérieur au solde disponible ne peut plus être sélectionné ; le débit enregistré correspond au montant réellement appliqué, y compris en mode Association.
- « Livret A » est retiré. « Enveloppe projet » permet de créer et sélectionner plusieurs sous-cagnottes nommées, avec la même durée de verrouillage et les mêmes frais que le compte Déclic.
- Le graphique des sept derniers jours est construit à partir des réussites, échecs et jours de pause réellement enregistrés.
- Les passages sont comptés par commerce. Le premier passage et les paliers de fidélité configurés déclenchent une notification d’offre dans l’application, notamment « 5e passage : un café offert ».

## Simulation et cagnotte 1.4.5

- Le bouton de remise à zéro efface les données locales et ferme l’application pour reproduire un premier lancement.
- La simulation suit le calendrier et le Point Déclic attribué à chaque jour actif.
- Cette version utilisait encore un jour mensuel ; ce comportement est remplacé par le seuil immédiat en 1.4.6.
- Chaque somme bloquée conserve sa propre échéance (1, 2, 3, 6 ou 12 mois).
- La part arrivée à échéance est affichée séparément ; un déblocage anticipé applique 5 % de frais simulés.
- Le relevé de dons téléchargé est un document de prototype, pas un reçu fiscal officiel.

## Personnalisation et commandes 1.4.5

- « Paysage Déclic » est le visuel initial d’un nouveau modèle ;
- zéro à trois visuels de la banque ou SVG importés peuvent être placés simultanément sur le recto ;
- la bibliothèque conserve jusqu’à trois SVG, même lorsqu’ils ne sont pas sélectionnés, avec suppression individuelle par une croix ;
- « Valider et commander » ouvre une confirmation récapitulative ; après « Oui, commander », la commande complète est envoyée à `/api/card-orders` ;
- une commande non transmise reste en attente sur le téléphone et repart automatiquement lorsque le serveur redevient accessible ;
- le serveur fourni affiche les commandes et propositions sur `http://localhost:8000`, avec actualisation chaque seconde.

Pour une liaison HTTP locale, construisez l’application depuis ce projet Android Studio : son manifeste autorise explicitement le trafic local du prototype. Une APK de production devra employer HTTPS, authentifier le compte et protéger les fichiers de fabrication.

## Carte, planning GPS et propositions 1.4.3

- lors de la première localisation GPS d’un nouveau profil : lundi et mercredi utilisent le point le plus proche, mardi et vendredi le deuxième, jeudi un point aléatoire, samedi et dimanche restent en pause ;
- les préférences déjà enregistrées ne sont jamais remplacées par cette initialisation ;
- un appui long sur un repère ouvre son nom, son adresse, ses horaires indicatifs et ses promotions en cours ;
- le formulaire « Proposer un commerce » est envoyé en JSON au serveur prototype ; une proposition non transmise est conservée localement puis renvoyée lorsque le serveur revient en ligne ;
- le serveur local est fourni dans `prototype-server` et son adresse est modifiable depuis l’application.

Le serveur local utilise HTTP pour les essais sur le même réseau. La version de production devra employer une API HTTPS authentifiée et des horaires issus de la base commerçants.

## Onboarding et tests 1.4.2

- validation obligatoire de l’adresse e-mail par un lien de prototype expirant après 30 minutes ;
- champs obligatoires signalés individuellement par un contour rouge ;
- contrôle du titulaire, du format du numéro de carte et conservation du seul numéro masqué ;
- cagnotte cible limitée de 5 € à 1 000 €, seuil automatique de 2 € minimum et inférieur à la cible, jour 5 par défaut ;
- validation de marche désactivée par défaut ;
- boutons « Déclic réussi » et « Déclic raté » mettant à jour points, statistiques, série et cagnotte.

L’envoi réel d’e-mails et la vérification de l’existence d’une carte devront être reliés à un serveur et à un prestataire de paiement. Le prototype simule le message reçu et vérifie le numéro par son checksum sans stocker le numéro complet.

## Correction de l’icône 1.4.1

Le fond beige arrondi et son ombre sont conservés. Seul le fond blanc extérieur dans les quatre coins devient transparent. Les pixels colorés du logo d’origine restent inchangés.

## Cartographie et cagnotte 1.4.0

Les partenaires ayant une offre portent une pastille orange sur leur repère. Les espaces verts ne sont jamais envoyés au fond cartographique ; sans carte personnelle, leur filtre conserve le message d'accès à la personnalisation. Les cartes « Tes Points Déclic » de l'accueil et du scanner reprennent le fond dégradé du réseau.

La cagnotte affiche désormais le solde réellement choisi dans le prototype : 20 € fictifs ou la cible configurée. Elle conserve un historique local des scans, remplissages et échecs. Un jour actif terminé sans scan déplace le montant par échec vers le compte de réserve. La durée de verrouillage peut être de 1, 3, 6 ou 12 mois. Le bouton de déblocage restitue la réserve dans le prototype ; les frais anticipés sont signalés mais volontairement non chiffrés ni appliqués tant que leur taux n'est pas défini.

## Accueil, scanner et paiement 1.3.9

Le scanner reprend le parcours direct de la version 1.3.7 : le QR `DEC-01-4827` valide immédiatement le Point Déclic choisi. Une seule validation est récompensée par jour ; les suivantes servent uniquement à consulter le lieu. Les compteurs de points, de série et de validations sont visibles sur l'accueil, sous le scanner et dans l'espace Points Déclic.

Le moteur local attribue +1 par premier check-in quotidien, +3 pour un nouveau partenaire, puis les bonus de série +5 à 5 jours, +15 à 14 jours et +30 à 30 jours. Les jours de pause ne cassent pas une série ; manquer un jour actif la réinitialise. Le solde, la série, les lieux visités et les vingt dernières opérations sont conservés localement.

Le profil ajoute une configuration de cagnotte, avec minimum de 10 €, montant cible, seuil de remplissage automatique et jour mensuel. L'onboarding laisse choisir entre 20 € fictifs sans débit ou cette configuration. Le prototype ne réalise aucun paiement et ne conserve que le titulaire et les quatre derniers chiffres : jamais le numéro complet ni un cryptogramme.

Ce dispositif démontre le parcours mais ne constitue pas une sécurité de production. La version réelle doit faire signer et vérifier les jetons par un serveur, contrôler la présence, enregistrer atomiquement la première validation quotidienne et déléguer les paiements à un prestataire certifié.

## Identité visuelle 1.3.9

Le visuel « D CLIC » fourni est utilisé uniquement comme icône Android sur l'écran d'accueil du téléphone. Son PNG conserve le carré beige arrondi et son ombre ; seul le blanc qui l’entoure est transparent. Dans l'application, l'en-tête et l'onboarding conservent l'affichage texte de la version 1.3.7. Le logo « D CLIC Commerçant » apparaît uniquement dans l'encadré « Vous êtes commerçant ? ».

## Points Déclic 1.3.6

- Le mode surprise global s'applique à chaque jour actif ; chaque jour peut aussi choisir individuellement « Point Déclic surprise » lorsque le mode global est désactivé.
- Les jours de pause restent prioritaires et ne déclenchent aucun tirage.
- « Parcs » devient « Espaces verts ». Sans carte personnelle, sélectionner ce filtre masque tous les repères et propose d'ouvrir la personnalisation.
- Le nouvel espace Points Déclic regroupe avantages, fidélité, information sur le QR au comptoir et proposition locale d'un commerce. L'envoi réseau reste simulé dans ce prototype : la proposition est conservée sur l'appareil.

## Personnalisation 1.3.5

Les jours du planning et des réglages sont synchronisés et enregistrés : vert actif, rouge pause. Le lieu reste mémorisé après une pause. L'éditeur ajoute rotation à deux doigts, guides aimantés, annulation, slogan ajusté au texte, contours noirs des emoji, vingt visuels cohérents et trois SVG statiques importés maximum (1 Mio chacun). Chaque import se déplace séparément. Les QR peuvent grandir sans descendre sous leur taille initiale. Le câble est une illustration générée, pas une photographie du produit final ; la notice d'origine est présentée en trois cadrages.

Le projet Java utilise ACTION_OPEN_DOCUMENT pour accorder l'accès aux seuls documents choisis, sans permission générale de stockage. La compilation Gradle de ce changement natif n'a pas été effectuée dans cet environnement. L'APK direct utilise le conteneur Nitron précompilé, qui possède déjà un sélecteur de fichiers ; importer un SVG à la fois si la sélection multiple n'est pas proposée. Son fonctionnement doit être confirmé sur le téléphone.

Tests : `node tests/editor-regression.cjs`, `node tests/days-regression.cjs` et `node tests/map-regression.cjs`. Il s'agit de tests logiques avec doubles DOM/Leaflet, pas de tests visuels ou tactiles sur Android.

## Ouvrir le projet

1. Décompressez le fichier ZIP.
2. Lancez Android Studio.
3. Choisissez **File > Open**.
4. Sélectionnez le dossier **Declic-Android-Studio** (celui qui contient `settings.gradle`).
5. Acceptez **Trust Project**, puis attendez la fin de **Gradle Sync**.

Au premier chargement, Android Studio peut télécharger Gradle 8.9 et les composants Android SDK 35.

## Lancer sur le téléphone

1. Activez les options développeur et le débogage USB sur le téléphone.
2. Branchez-le en USB et acceptez l'autorisation de débogage.
3. Sélectionnez le téléphone dans la barre supérieure d'Android Studio.
4. Cliquez sur **Run ▶**.
5. Dans Déclic, autorisez la caméra pour le scanner et la localisation pour centrer la carte sur le GPS.

La carte OpenStreetMap nécessite une connexion Internet. L'adresse manuelle reste disponible avec l'icône crayon.

Le QR de test inclus contient `DEC-01-4827` et se trouve dans :

`app/src/main/assets/qr-declic-DEC-01-4827.gif`

## Générer un APK

Dans Android Studio : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

L'APK de débogage sera créé dans :

`app/build/outputs/apk/debug/app-debug.apk`


## Cartographie 1.3.4

Leaflet 1.9.4 et MarkerCluster 1.5.3 sont embarqués dans les assets. Aucune clé API n'est requise. Le fond de carte nécessite Internet ; les lieux affichés restent les données du prototype, pas un annuaire de commerçants partenaires vérifiés.

- Les marqueurs, le point de départ et le cercle en mètres utilisent la projection de Leaflet.
- Les groupes numérotés se détaillent au zoom ; au zoom maximal les points superposés se déploient.
- Les filtres et la sélection conservent la vue. Le changement de rayon ou de point de départ recadre le cercle.
- Une adresse non trouvée conserve le centre précédent. Les recherches d'adresse concernent la France.
- Le module carte est initialisé uniquement lors de l'ouverture de l'onglet.

### Services publics du prototype

Les tuiles OSM restent soumises à https://operations.osmfoundation.org/policies/tiles/ : attribution visible, cache HTTP normal, pas de téléchargement massif/hors ligne. Le projet Android Studio ajoute un User-Agent Déclic. L'APK direct conserve le WebView Nitron précompilé et son identification Android automatique ; vérifier les accès réseau sur le téléphone.

La recherche manuelle existante utilise Nominatim, conformément aux contraintes de https://operations.osmfoundation.org/policies/nominatim/ : recherche explicite uniquement, aucun autocomplètement, cache de session, une requête à la fois, au moins 1,1 seconde entre départs de requêtes. Le quota d'une requête/seconde s'applique à l'ensemble de l'application ; ce client est réservé au test individuel. Avant une diffusion multi-utilisateur, prévoir un service/proxy adapté. Aucune recherche n'est lancée en arrière-plan.

Le développeur peut changer les services sans reconstruire l'application depuis le stockage local du WebView : `declic.mapTilesUrl` (modèle HTTPS avec `{z}/{x}/{y}`), `declic.geocoderUrl` (service HTTPS compatible Nominatim JSONP). Recharger après modification. Adapter l'attribution si un autre fournisseur de tuiles est utilisé.

### Vérifications

`node tests/map-regression.cjs` contrôle la logique du module avec un double de Leaflet : coordonnées, distances, rayon, filtres, sélection sans recentrage, conservation des groupes déployés et résultats vides. Les fichiers JavaScript sont également vérifiés syntaxiquement. Ces contrôles ne remplacent pas un test de rendu.

Le navigateur de cet environnement refuse les pages locales : aucun test visuel ni test des gestes Android n'a pu être effectué ici. Sur Honor View 20 : ouvrir Carte, zoomer/déplacer, détailler un groupe, choisir un lieu, changer les catégories et le rayon, puis tester GPS et adresse. Les permissions GPS/caméra et le scanner existants sont conservés.
