# Déclic Android 1.6.1 — Créateur de routine

- Nouveau module « Créateur de routine » accessible depuis Mon rituel.
- Parcours guidé, choix par choix, avec sous-choix conditionnels.
- Exemple préchargé : moment, lieu, rythme, distance, période, somme et mode.
- Simulation aléatoire d’un engagement complet.
- Sauvegarde locale hors ligne dans le navigateur intégré.
- Application directe de la phrase générée aux réglages Déclic.
- Identité visuelle Déclic conservée : crème, vert sauge et terracotta.
- Compatibilité conservée à partir d’Android 5.0 (API 21).
