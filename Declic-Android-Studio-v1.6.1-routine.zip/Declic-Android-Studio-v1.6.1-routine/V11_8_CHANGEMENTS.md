# Déclic Usager 1.5.5 / serveur V11.9

- Toute modification de paramètre déclenche une synchronisation rapide vers le serveur, avec un contrôle périodique de secours toutes les secondes.
- L’APK envoie toujours aussi l’ensemble des clés `declic.*` de son localStorage et son état runtime : profil, mode, épargne, association, enveloppes, réveil, jours actifs, planning des Points, carte, jokers, exemptions, récompenses, etc.
- Le serveur reste informé des formulaires et commandes via les routes dédiées ; la fiche usager serveur regroupe ces données avec le snapshot brut de l’APK.
- Le calendrier Exemptions / Joker reprend maintenant exactement les résultats du suivi : journée validée dans la couleur Déclic sélectionnée sur l’Accueil, oubli en orange.
- Les validations connues du serveur sont également reprises dans le calendrier, ce qui évite de perdre la couleur d’une réussite après une resynchronisation.
- Changer le thème de l’Accueil recolore immédiatement les journées réussies du calendrier.
