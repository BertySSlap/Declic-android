# Générer l’APK dans Android Studio

1. Décompresser le projet.
2. Ouvrir le dossier du projet dans Android Studio.
3. Attendre la synchronisation Gradle.
4. Ouvrir **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Cliquer sur **Locate** après la compilation.

L’APK de test se trouve normalement dans :

`app/build/outputs/apk/debug/app-debug.apk`

Configuration :

- applicationId : `com.declic.app`
- version : `1.6.1-routine`
- Android minimum : 5.0 / API 21
- Java : 17
