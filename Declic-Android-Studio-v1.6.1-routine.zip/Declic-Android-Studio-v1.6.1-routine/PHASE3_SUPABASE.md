# Déclic Phase 3 — Usager 1.6.0-supabase

Cette branche se connecte directement à Supabase.

Projet: `déclic app phase 3`
URL: `https://bssxgbyzqtadyqcdwguf.supabase.co`

- Authentification persistante par Supabase Auth.
- La clé intégrée est une **publishable key** prévue pour les clients publics, jamais une clé `service_role`.
- Le serveur PowerShell V11.x n'est plus lancé automatiquement dans cette branche.
- Les données structurées et un snapshot brut de l'état de l'application remontent dans Supabase.
- L'application usager relit le catalogue commerçant toutes les 2 secondes pendant ce jalon de migration.
