DÉCLIC V11.5 — MODIFICATIONS DES SCREENSHOTS ANNOTÉS

Les noms des captures ont été utilisés comme instructions principales, car l’écriture manuscrite est difficile à lire.

CÔTÉ COMMERÇANT
1. Recommander un Point Déclic : le bouton Continuer ouvre désormais la page web commerçant du serveur pour commander un Point supplémentaire ou de remplacement.
2. Accès Patron / Employé : choix au démarrage. Le patron a l’accès complet ; l’employé conserve les actions opérationnelles (stats, offres, fidélité, signalements) mais pas la facturation, l’équipe, la fiche sensible ni les commandes/réinitialisations de matériel.
3. Signalement : jusqu’à 3 photos peuvent être ajoutées dans le champ Détails, avec aperçu et suppression avant envoi.
4. Offres : pictogramme remplacé par une icône en trait cohérente ; suppression directe corrigée.
5. Tableau de bord : blocs « Visites validées » et « Récompenses utilisées » retirés ; « Visiteurs fidèles » et « Visiteurs uniques » sont placés sous le graphique des passages.
6. Offres : bouton « Mettre en pause / Réactiver » + interrupteur dans l’éditeur ; suppression fonctionnelle.

CÔTÉ USAGER
- Conservation des règles V11.4 (recharge automatique, historique, fidélité, offres après scan, etc.).
- Sous-cagnottes/projets complétées : chaque projet peut définir sa propre durée de blocage et son propre pourcentage de frais de déblocage anticipé.

SERVEUR
- Modèle V11.5.
- Formulaires avec jusqu’à 3 pièces jointes photo.
- Rôles owner/employee appliqués aussi côté serveur aux mises à jour du commerce.
- Nouvelle page /commande-point pour les commandes de Point Déclic depuis l’app commerçant.

TEST RAPIDE
1. Lancer START_SERVER.bat.
2. Lancer ADB_REVERSE_ANDROID.bat avec le téléphone branché.
3. Ouvrir les deux projets dans Android Studio puis Run.
4. Dans l’app commerçant, choisir Patron ou Employé et vérifier les droits.
5. Tester une offre : pause, reprise, suppression.
6. Tester un signalement avec 1 à 3 photos.
7. Comme Patron, « Recommander un Point Déclic » doit ouvrir la page web du serveur.
8. Dans l’app usager, créer une sous-cagnotte avec durée et frais personnalisés.
