# Déclic V11.7 — données serveur complètes

## Convention des jours
- JavaScript / serveur : dimanche = `0`, lundi = `1`, ... samedi = `6`.
- Les anciennes valeurs `7` sont migrées automatiquement vers `0`.
- Le planning Point Déclic est stocké avec les mêmes clés (`0` à `6`).

## Profil usager synchronisé
Le serveur reçoit et affiche notamment : nom affiché, téléphone, ville, type de Point préféré, jours actifs, planning hebdomadaire, réglages de validation, préférences de carte et paramètres de cagnotte.

L'adresse e-mail est un cas particulier : une modification crée d'abord une adresse en attente et un jeton de confirmation. L'adresse principale du serveur n'est remplacée qu'après confirmation via `/api/users/<id>/email/confirm`.

## Réveil et validation
Le serveur conserve :
- liaison au réveil ON/OFF ;
- délai choisi après le réveil : 30, 45, 60, 90, 120 ou 180 minutes ;
- dernier réveil détecté et horodatage ;
- heure fixe, marge silencieuse, QR et marche.

## Exemptions et jokers
Le serveur conserve les exemptions, le calendrier de joker de l'app, les dates protégées, les jokers inclus/supplémentaires utilisés et le nombre encore disponible. L'utilisation du joker inclus est synchronisée entre le calendrier de l'app et les compteurs serveur.

## Espace Déclic et avantages
Le serveur expose les statistiques usager : points, validations, lieux uniques visités, série, avantages obtenus, actifs et utilisés. Les avantages de fidélité gagnés après une validation sont enregistrés et peuvent être marqués comme utilisés.

## Commerçants
La vue serveur expose le maximum de paramètres disponibles : profil commerce, abonnement, rôle, visibilité, Point Déclic, QR, BLE, batterie, fuseau, horaires, offres, fidélité, statistiques et état brut de l'application.

`Commerce invisible : ON/OFF` remplace le libellé métier « commerce fermé ». Le champ historique `closed` reste uniquement pour compatibilité avec les versions précédentes.

## Formulaires
Les formulaires, dont « proposer un commerce », sont visibles côté serveur avec leur propriétaire, message, métadonnées et pièces jointes éventuelles.

## Plafond mensuel
`monthly_cap` représente la limite mensuelle prévue pour le total d'argent pouvant être retiré ou bloqué à cause des échecs de routine. `wallet_monthly_debited` indique le montant déjà utilisé durant le mois. Dans ce prototype, la valeur est synchronisée et visualisée ; l'application serveur complète de la limite sera liée au futur traitement backend des journées ratées.
