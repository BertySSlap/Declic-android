# Déclic n'utilise aucune règle ProGuard particulière pour le moment.
