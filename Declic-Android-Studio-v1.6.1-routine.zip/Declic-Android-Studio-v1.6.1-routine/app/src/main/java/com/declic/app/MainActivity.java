package com.declic.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.Collections;
import java.util.Enumeration;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class MainActivity extends Activity {
    private static final int CAMERA_PERMISSION_REQUEST = 1001;
    private static final int LOCATION_PERMISSION_REQUEST = 1002;
    private static final int FILE_PICKER_REQUEST = 1003;
    private ValueCallback<Uri[]> pendingFilePicker;
    private static final long LOCATION_TIMEOUT_MS = 12000L;

    private WebView webView;
    private PermissionRequest pendingWebPermissionRequest;
    private boolean cameraPermissionRequestInFlight;
    private boolean locationPermissionRequestInFlight;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private Location fallbackLocation;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable locationTimeout = () -> {
        if (fallbackLocation != null) {
            deliverLocation(fallbackLocation);
        } else {
            deliverLocationError("Position introuvable. Active le GPS puis réessaie.");
        }
    };

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUserAgentString(settings.getUserAgentString() + " DeclicPrototype/1.6.1-routine (com.declic.app)");
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        settings.setMediaPlaybackRequiresUserGesture(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    WebChromeClient.FileChooserParams params) {
                if (pendingFilePicker != null) pendingFilePicker.onReceiveValue(null);
                pendingFilePicker = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,
                        params.getMode() == WebChromeClient.FileChooserParams.MODE_OPEN_MULTIPLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(intent, FILE_PICKER_REQUEST);
                } catch (ActivityNotFoundException error) {
                    pendingFilePicker.onReceiveValue(null);
                    pendingFilePicker = null;
                    android.widget.Toast.makeText(MainActivity.this,
                            "Aucun sélecteur de fichiers disponible", android.widget.Toast.LENGTH_LONG).show();
                }
                return true;
            }
            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> handleWebPermissionRequest(request));
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                if (request == pendingWebPermissionRequest) {
                    pendingWebPermissionRequest = null;
                }
            }
        });

        webView.addJavascriptInterface(new AndroidBridge(), "android");
        boolean isDebuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        WebView.setWebContentsDebuggingEnabled(isDebuggable);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void handleWebPermissionRequest(PermissionRequest request) {
        boolean asksForCamera = false;
        for (String resource : request.getResources()) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                asksForCamera = true;
                break;
            }
        }

        if (!asksForCamera) {
            request.deny();
            return;
        }

        if (hasCameraPermission()) {
            request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
        } else {
            pendingWebPermissionRequest = request;
            askForCameraPermission();
        }
    }

    private boolean hasCameraPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
    }

    private void askForCameraPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && !hasCameraPermission()
                && !cameraPermissionRequestInFlight) {
            cameraPermissionRequestInFlight = true;
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        }
    }

    private boolean hasLocationPermission() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestCurrentLocation() {
        if (!hasLocationPermission()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !locationPermissionRequestInFlight) {
                locationPermissionRequestInFlight = true;
                requestPermissions(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                }, LOCATION_PERMISSION_REQUEST);
            }
            return;
        }
        findCurrentLocation();
    }

    @SuppressLint("MissingPermission")
    private void findCurrentLocation() {
        cleanupLocationRequest();
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (locationManager == null) {
            deliverLocationError("Service de localisation indisponible.");
            return;
        }

        fallbackLocation = newestLocation(
                locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER),
                locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER));

        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location != null) deliverLocation(location);
            }

            @Override public void onStatusChanged(String provider, int status, Bundle extras) { }
            @Override public void onProviderEnabled(String provider) { }
            @Override public void onProviderDisabled(String provider) { }
        };

        boolean requested = false;
        try {
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.GPS_PROVIDER, 0L, 0f, locationListener, Looper.getMainLooper());
                requested = true;
            }
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                locationManager.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER, 0L, 0f, locationListener, Looper.getMainLooper());
                requested = true;
            }
        } catch (RuntimeException ignored) {
            // Le dernier point connu reste utilisable si un fournisseur échoue.
        }

        if (!requested) {
            if (fallbackLocation != null) deliverLocation(fallbackLocation);
            else deliverLocationError("Active la localisation du téléphone puis réessaie.");
            return;
        }
        mainHandler.postDelayed(locationTimeout, LOCATION_TIMEOUT_MS);
    }

    private Location newestLocation(Location first, Location second) {
        if (first == null) return second;
        if (second == null) return first;
        return first.getTime() >= second.getTime() ? first : second;
    }

    private void deliverLocation(Location location) {
        cleanupLocationRequest();
        if (webView == null) return;
        String javascript = "window.onAndroidLocation(" + location.getLatitude()
                + "," + location.getLongitude() + ");";
        webView.evaluateJavascript(javascript, null);
    }

    private void deliverLocationError(String message) {
        cleanupLocationRequest();
        if (webView == null) return;
        webView.evaluateJavascript(
                "window.onAndroidLocationError(" + JSONObject.quote(message) + ");", null);
    }


    private void discoverDeclicServerOnLan() {
        new Thread(() -> {
            String found = null;
            String localIp = findLocalIpv4();
            if (localIp != null) {
                int lastDot = localIp.lastIndexOf('.');
                if (lastDot > 0) {
                    String prefix = localIp.substring(0, lastDot + 1);
                    found = scanSubnetPort(prefix, 8765);
                    if (found == null) {
                        for (int port = 8766; port <= 8785 && found == null; port++) {
                            found = scanSubnetPort(prefix, port);
                        }
                    }
                }
            }
            final String result = found == null ? "" : found;
            runOnUiThread(() -> {
                if (webView != null) {
                    webView.evaluateJavascript(
                            "window.onDeclicServerDiscovered && window.onDeclicServerDiscovered(" +
                                    JSONObject.quote(result) + ");", null);
                }
            });
        }, "DeclicWifiDiscovery").start();
    }

    private String findLocalIpv4() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            if (interfaces == null) return null;
            for (NetworkInterface network : Collections.list(interfaces)) {
                if (!network.isUp() || network.isLoopback()) continue;
                for (InetAddress address : Collections.list(network.getInetAddresses())) {
                    if (!(address instanceof Inet4Address) || address.isLoopbackAddress()) continue;
                    String ip = address.getHostAddress();
                    if (ip == null || ip.startsWith("169.254.")) continue;
                    if (ip.startsWith("10.") || ip.startsWith("192.168.") ||
                            ip.matches("172\\.(1[6-9]|2[0-9]|3[0-1])\\..*")) {
                        return ip;
                    }
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private String scanSubnetPort(String prefix, int port) {
        ExecutorService pool = Executors.newFixedThreadPool(48);
        CompletionService<String> completion = new ExecutorCompletionService<>(pool);
        int submitted = 0;
        for (int host = 1; host <= 254; host++) {
            final String base = "http://" + prefix + host + ":" + port;
            completion.submit(() -> isDeclicServer(base) ? base : null);
            submitted++;
        }
        try {
            for (int i = 0; i < submitted; i++) {
                Future<String> future = completion.take();
                String result = future.get();
                if (result != null) {
                    pool.shutdownNow();
                    return result;
                }
            }
        } catch (Exception ignored) { }
        finally {
            pool.shutdownNow();
        }
        return null;
    }

    private boolean isDeclicServer(String base) {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(base + "/api/health").openConnection();
            connection.setConnectTimeout(140);
            connection.setReadTimeout(220);
            connection.setUseCaches(false);
            connection.setRequestMethod("GET");
            if (connection.getResponseCode() != 200) return false;
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null && body.length() < 4096) body.append(line);
            reader.close();
            String text = body.toString();
            return text.contains("\"ok\":true") && text.contains("\"version\":\"V11");
        } catch (Exception ignored) {
            return false;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void cleanupLocationRequest() {
        mainHandler.removeCallbacks(locationTimeout);
        if (locationManager != null && locationListener != null) {
            try {
                locationManager.removeUpdates(locationListener);
            } catch (SecurityException ignored) { }
        }
        locationListener = null;
        fallbackLocation = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST) {
            locationPermissionRequestInFlight = false;
            if (hasLocationPermission()) findCurrentLocation();
            else deliverLocationError("Autorise la localisation pour utiliser le GPS.");
            return;
        }

        if (requestCode != CAMERA_PERMISSION_REQUEST) return;

        cameraPermissionRequestInFlight = false;
        boolean granted = grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (pendingWebPermissionRequest != null) {
            if (granted) {
                pendingWebPermissionRequest.grant(
                        new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
            } else {
                pendingWebPermissionRequest.deny();
            }
            pendingWebPermissionRequest = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_PICKER_REQUEST || pendingFilePicker == null) return;
        java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    Uri uri = data.getClipData().getItemAt(i).getUri();
                    if (uri != null && "content".equals(uri.getScheme())) uris.add(uri);
                }
            } else if (data.getData() != null && "content".equals(data.getData().getScheme())) {
                uris.add(data.getData());
            }
        }
        pendingFilePicker.onReceiveValue(uris.isEmpty() ? null : uris.toArray(new Uri[0]));
        pendingFilePicker = null;
    }

    @Override
    protected void onDestroy() {
        if (pendingFilePicker != null) {
            pendingFilePicker.onReceiveValue(null);
            pendingFilePicker = null;
        }
        cleanupLocationRequest();
        if (pendingWebPermissionRequest != null) {
            pendingWebPermissionRequest.deny();
            pendingWebPermissionRequest = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("android");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private final class AndroidBridge {
        @JavascriptInterface
        public void requestPermission(String permission) {
            if ("CAMERA".equalsIgnoreCase(permission)) {
                runOnUiThread(MainActivity.this::askForCameraPermission);
            }
        }

        @JavascriptInterface
        public void requestLocation() {
            runOnUiThread(MainActivity.this::requestCurrentLocation);
        }

        @JavascriptInterface
        public void discoverServer() {
            discoverDeclicServerOnLan();
        }

        @JavascriptInterface
        public void closeAfterReset() {
            runOnUiThread(() -> {
                if (webView != null) webView.clearCache(false);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) finishAndRemoveTask();
                else finishAffinity();
            });
        }
    }
}
