(function(){
  'use strict';
  const drawings=[
    ['sun','Soleil','<circle cx="32" cy="32" r="11"/><path d="M32 6v8m0 36v8M6 32h8m36 0h8M14 14l6 6m24 24 6 6m0-36-6 6M20 44l-6 6"/>'],
    ['leaf','Feuille','<path d="M13 51C10 24 28 11 52 12c1 25-12 43-39 39Zm0 0 29-29M26 38V26m0 12h13"/>'],
    ['coffee','Café','<path d="M14 25h30v15a12 12 0 0 1-12 12h-6a12 12 0 0 1-12-12Zm30 3h5a7 7 0 0 1 0 14h-5M10 57h39M23 19c-7-6 6-7 0-13m10 13c-7-6 6-7 0-13"/>'],
    ['bread','Croissant','<path d="M9 44c-7-15 5-29 23-29s30 14 23 29l-12-6c-6 7-16 7-22 0Zm-1-6 11-2M15 23l9 17M26 16l3 24M39 16l-3 24M49 23l-9 17m4-4 12 2"/>'],
    ['mountain','Montagne','<path d="m6 51 19-34 12 21 7-12 14 25ZM18 29l7 4 6-4M39 35l5 3 5-3M6 57h52"/>'],
    ['waves','Vagues','<path d="M6 22c9-12 17 12 26 0s17 12 26 0M6 33c9-12 17 12 26 0s17 12 26 0M6 44c9-12 17 12 26 0s17 12 26 0"/>'],
    ['tree','Arbre','<path d="M32 57V28m0 15 10-9m-10 3-8-8M22 55h20"/><path d="M20 42a13 13 0 0 1-5-24A17 17 0 0 1 48 18a13 13 0 0 1-4 24"/>'],
    ['flower','Fleur','<circle cx="32" cy="27" r="5"/><path d="M27 22c-10-17 20-17 10 0 17-10 17 20 0 10 10 17-20 17-10 0-17 10-17-20 0-10Zm5 22v14m0-5c-12 0-15-4-15-9 9 0 15 3 15 9"/>'],
    ['compass','Boussole','<circle cx="32" cy="32" r="24"/><path d="m22 42 5-15 15-5-5 15ZM32 8v5m24 19h-5M32 56v-5M8 32h5"/>'],
    ['pin','Lieu','<path d="M49 26c0 14-17 30-17 30S15 40 15 26a17 17 0 1 1 34 0Z"/><circle cx="32" cy="25" r="6"/>'],
    ['heart','Cœur','<path d="M32 54 12 34C-3 17 19 2 32 18 45 2 67 17 52 34Z"/>'],
    ['footprints','Petits pas','<path d="M13 32c-5-10-1-22 5-21s10 9 7 18l-2 6Zm2 7 8 2c3 9-6 14-9 8ZM42 23c-2-10 2-19 8-18s8 13 2 22Zm-1 7 8 3c1 10-9 12-10 5Z"/>'],
    ['bird','Oiseau','<path d="M7 43c19 4 26-6 31-23 4-12 15-12 16-1l6 5-10 2c-4 19-18 24-35 23ZM11 28l19 12M48 16h.1"/>'],
    ['book','Livre','<path d="M32 17C24 10 13 10 7 13v38c8-3 17-2 25 4 8-6 17-7 25-4V13c-6-3-17-3-25 4Zm0 0v38M14 22c5-1 8 0 12 2m-12 7c5-1 8 0 12 2m12-9c4-2 7-3 12-2m-12 11c4-2 7-3 12-2"/>'],
    ['moon','Lune','<path d="M42 8A23 23 0 1 0 56 43 22 22 0 0 1 42 8Z"/><path d="m50 12 1 4 4 1-4 1-1 4-1-4-4-1 4-1Z"/>'],
    ['sprout','Jeune pousse','<path d="M32 57V34C14 35 8 23 9 12c15 0 25 5 23 22Zm0-1C31 20 42 15 56 16c0 13-9 20-24 17M17 56h30"/>'],
    ['bench','Banc','<path d="M9 22h46v14H9Zm0 7h46M5 43h54M13 36v7m38-7v7M12 43v13m40-13v13M16 16v6m32-6v6"/>'],
    ['sunrise','Aube','<path d="M6 43h52M20 43a12 12 0 0 1 24 0M32 14v8M12 23l6 6m34-6-6 6M10 51h44M18 58h28"/>'],
    ['cloud','Nuage','<path d="M18 44a12 12 0 1 1 1-24 16 16 0 0 1 30 5 10 10 0 0 1-2 19ZM24 50v7m9-7v7m9-7v7"/>']
  ];
  const icons=[{id:'route',name:'Paysage Déclic',svg:visualContents.route}];
  drawings.forEach(d=>icons.push({id:d[0],name:d[1],svg:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+d[2]+'</svg>'}));
  window.DeclicIcons=icons;
})();
