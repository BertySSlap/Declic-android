/* Déclic map: geographic layers share Leaflet's projection and gesture handling. */
(function () {
  'use strict';
  var map = null, tiles = null, circle = null, origin = null, pins = null;
  var state = null, markers = {}, pendingFit = true, lastKey = '', lastTilesOk = 0;
  var TILE_URL = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
  try {
    var customTiles = localStorage.getItem('declic.mapTilesUrl');
    if (customTiles && /^https:\/\//.test(customTiles)) TILE_URL = customTiles;
  } catch (_) {}

  function colour() {
    return getComputedStyle(document.documentElement).getPropertyValue('--green').trim() || '#2b7e59';
  }
  function status(text) {
    var box = document.getElementById('mapNetworkStatus');
    box.textContent = text;
    box.classList.toggle('hidden', !text);
  }
  function fit() {
    if (!map || !circle || !document.getElementById('osmMap').clientHeight) return;
    map.invalidateSize({pan: false});
    map.fitBounds(circle.getBounds(), {padding: [24, 24], maxZoom: 18, animate: false});
    pendingFit = false;
  }
  function ensureMap() {
    if (map) return true;
    if (!state || !state.center || !document.getElementById('osmMap').clientHeight) return false;
    if (!window.L || !L.markerClusterGroup) {
      status('La carte ne peut pas démarrer. Réinstalle la dernière version de Déclic.');
      return false;
    }
    map = L.map('osmMap', {minZoom: 3, maxZoom: 19, scrollWheelZoom: false,
      zoomControl: false, attributionControl: true}).setView([state.center.lat,state.center.lon], 15);
    L.control.zoom({position: 'bottomright', zoomInTitle: 'Agrandir la carte',
      zoomOutTitle: 'Réduire la carte'}).addTo(map);
    L.control.scale({imperial: false, position: 'bottomleft'}).addTo(map);
    map.attributionControl.setPrefix(false);
    tiles = L.tileLayer(TILE_URL, {maxZoom: 19, updateWhenIdle: true, keepBuffer: 1,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'}).addTo(map);
    tiles.on('loading', function () { lastTilesOk = 0; });
    tiles.on('tileload', function () { lastTilesOk++; status(''); });
    tiles.on('load', function () {
      if (!lastTilesOk) status('Fond de carte indisponible. Vérifie ta connexion puis appuie sur Réessayer.');
    });
    tiles.on('tileerror', function () {
      if (!lastTilesOk) status('Fond de carte indisponible. Vérifie ta connexion puis appuie sur Réessayer.');
    });
    pins = L.markerClusterGroup({maxClusterRadius: 48, showCoverageOnHover: false,
      spiderfyOnMaxZoom: true, zoomToBoundsOnClick: true, animate: false,
      spiderLegPolylineOptions: {weight: 1.5, color: colour()},
      iconCreateFunction: function (cluster) {
        return L.divIcon({className: 'declic-cluster', iconSize: [44, 44],
          html: '<span>' + cluster.getChildCount() + '</span>'});
      }}).addTo(map);
    return true;
  }
  function pinIcon(place, selected) {
    var el = document.createElement('span');
    el.className = 'declic-pin-face' + (selected ? ' selected' : '') + (place.hasOffer ? ' has-offer' : '');
    el.textContent = place.icon;
    return L.divIcon({className: 'declic-leaflet-pin', html: el.outerHTML,
      iconSize: [38, 44], iconAnchor: [19, 44], popupAnchor: [0, -42]});
  }
  function paint() {
    if (!ensureMap()) return;
    var centre = [state.center.lat, state.center.lon];
    if (!circle) {
      circle = L.circle(centre, {radius: state.radius, color: colour(), weight: 2,
        dashArray: '7 6', fillColor: colour(), fillOpacity: 0.08, interactive: false}).addTo(map);
      origin = L.circleMarker(centre, {radius: 7, color: '#fff', weight: 3,
        fillColor: '#3478dc', fillOpacity: 1, interactive: false}).addTo(map);
    }
    circle.setLatLng(centre).setRadius(state.radius).setStyle({color: colour(), fillColor: colour()});
    origin.setLatLng(centre);
    // A selected card must not reset the user's zoom or collapse a spiderfied group.
    var key = state.places.map(function (p) { return p.id + ':' + p.lat + ':' + p.lon; }).join('|');
    if (key !== lastKey) {
      pins.clearLayers(); markers = {};
      state.places.forEach(function (place) {
        var longPressTimer = null, longPressTriggered = false;
        var marker = L.marker([place.lat, place.lon], {icon: pinIcon(place, place.id === state.selected),
          title: place.name + (place.hasOffer ? ' · Offre disponible' : ''), alt: place.name, keyboard: true, riseOnHover: true});
        function beginLongPress() {
          longPressTriggered = false;
          clearTimeout(longPressTimer);
          longPressTimer = setTimeout(function () {
            longPressTriggered = true;
            if (state.onLongPress) state.onLongPress(place.id);
          }, 650);
        }
        function cancelLongPress() { clearTimeout(longPressTimer); longPressTimer = null; }
        marker.on('mousedown', beginLongPress);
        marker.on('touchstart', beginLongPress);
        marker.on('mouseup', cancelLongPress);
        marker.on('mouseout', cancelLongPress);
        marker.on('touchend', cancelLongPress);
        marker.on('contextmenu', function (event) {
          cancelLongPress();
          longPressTriggered = true;
          if (event && event.originalEvent && event.originalEvent.preventDefault) event.originalEvent.preventDefault();
          if (state.onLongPress) state.onLongPress(place.id);
        });
        marker.on('click', function () {
          if (longPressTriggered) { longPressTriggered = false; return; }
          state.onSelect(place.id);
        });
        markers[place.id] = marker;
        pins.addLayer(marker);
      });
      lastKey = key;
    }
    state.places.forEach(function (place) {
      var marker = markers[place.id];
      if (!marker) return;
      marker.setIcon(pinIcon(place, place.id === state.selected));
      marker.setZIndexOffset(place.id === state.selected ? 1000 : 0);
    });
    if (pendingFit) fit();
  }
  window.DeclicMap = {
    update: function (next) {
      if (!state || !state.center || !next.center || state.radius !== next.radius ||
          state.center.lat !== next.center.lat || state.center.lon !== next.center.lon) pendingFit = true;
      state = next;
      paint();
    },
    show: function () {
      paint();
      if (map) { map.invalidateSize({pan: false}); if (pendingFit) fit(); }
    },
    recenter: function () { pendingFit = true; paint(); },
    theme: function () {
      if (circle) circle.setStyle({color: colour(), fillColor: colour()});
    }
  };
  document.getElementById('recenterMapBtn').addEventListener('click', function () { window.DeclicMap.recenter(); });
  document.getElementById('retryMapBtn').addEventListener('click', function () {
    if (tiles) { status('Chargement du fond de carte…'); tiles.redraw(); }
    else window.DeclicMap.show();
  });
  window.addEventListener('resize', function () {
    if (map && document.getElementById('osmMap').clientHeight) map.invalidateSize({pan: false});
  });
  window.addEventListener('online', function () { if (tiles) tiles.redraw(); });
}());
