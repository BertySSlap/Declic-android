(function(root){
  'use strict';
  const clamp=(v,min,max)=>Math.max(min,Math.min(max,v));
  function normalize(id,value){
    const v=value||{},isQr=/-qr$/.test(id),resizable=isQr||id==='art'||/^import-/.test(id)||/^visual-/.test(id);
    return {x:Number.isFinite(v.x)?v.x:0,y:Number.isFinite(v.y)?v.y:0,
      rotation:Number.isFinite(v.rotation)?v.rotation:0,
      scale:resizable?clamp(Number.isFinite(v.scale)?v.scale:1,isQr?1:.15,4):1};
  }
  function angle(a,b){return Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;}
  function deltaAngle(a,b){return ((b-a+540)%360)-180;}
  function rotatedSize(width,height,rotation){
    const r=rotation*Math.PI/180,c=Math.abs(Math.cos(r)),s=Math.abs(Math.sin(r));
    return {width:width*c+height*s,height:width*s+height*c};
  }
  function nearest(values,targets,tolerance){
    let result=null;
    values.forEach(value=>targets.forEach(target=>{
      const delta=target-value;
      if(Math.abs(delta)<=tolerance&&(!result||Math.abs(delta)<Math.abs(result.delta))) result={delta,target};
    }));return result;
  }
  const api={clamp,normalize,angle,deltaAngle,rotatedSize,nearest};
  root.DeclicEditorCore=api;
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
})(typeof window!=='undefined'?window:this);
