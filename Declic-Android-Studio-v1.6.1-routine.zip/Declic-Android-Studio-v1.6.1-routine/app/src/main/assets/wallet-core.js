(function(root,factory){
  var api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.DeclicWalletCore=api;
})(typeof self!=='undefined'?self:this,function(){
  'use strict';

  function money(value){
    var parsed=Number(value);
    return Number.isFinite(parsed)?Math.max(0,Math.round(parsed*100)/100):0;
  }

  function dayKey(date){
    return date.getFullYear()+'-'+String(date.getMonth()+1).padStart(2,'0')+'-'+String(date.getDate()).padStart(2,'0');
  }

  function previousDayKey(date){
    var previous=new Date(date.getFullYear(),date.getMonth(),date.getDate()-1,12);
    return dayKey(previous);
  }

  function addMonths(date,months){
    var result=new Date(date.getFullYear(),date.getMonth(),date.getDate(),12);
    var originalDay=result.getDate();
    result.setDate(1);
    result.setMonth(result.getMonth()+Math.max(1,Number(months)||1));
    var lastDay=new Date(result.getFullYear(),result.getMonth()+1,0,12).getDate();
    result.setDate(Math.min(originalDay,lastDay));
    return result;
  }

  function create(opening,target,date){
    var amount=money(opening);
    return {available:amount,locked:0,lockedEntries:[],donated:0,feesPaid:0,target:Math.max(5,money(target)||amount||20),processedThrough:previousDayKey(date||new Date()),transactions:[]};
  }

  function normalize(input,opening,target,date){
    var state=input&&typeof input==='object'?input:create(opening,target,date||new Date());
    var entries=Array.isArray(state.lockedEntries)?state.lockedEntries.map(function(entry,index){
      return {
        id:String(entry.id||'lock-'+index),amount:money(entry.amount),
        lockedAt:String(entry.lockedAt||dayKey(date||new Date())),
        unlockAt:String(entry.unlockAt||dayKey(addMonths(date||new Date(),1))),
        projectId:String(entry.projectId||''),projectName:String(entry.projectName||''),unlockFeePercent:5
      };
    }).filter(function(entry){return entry.amount>0;}):[];
    var legacyLocked=money(state.locked);
    if(!entries.length&&legacyLocked)entries.push({id:'legacy-lock',amount:legacyLocked,lockedAt:dayKey(date||new Date()),unlockAt:dayKey(addMonths(date||new Date(),1))});
    var locked=money(entries.reduce(function(sum,entry){return sum+entry.amount;},0));
    return {available:money(state.available),locked:locked,lockedEntries:entries,donated:money(state.donated),feesPaid:money(state.feesPaid),target:Math.max(5,money(state.target)||money(target)||20),processedThrough:String(state.processedThrough||previousDayKey(date||new Date())),transactions:Array.isArray(state.transactions)?state.transactions.slice(0,50):[]};
  }

  function addTransaction(state,item){if(!item.id)item.id='wallet-'+Date.now()+'-'+Math.random().toString(36).slice(2,8);state.transactions.unshift(item);state.transactions=state.transactions.slice(0,50);}

  function recordFailure(input,amount,date,lockMonths,mode,donationPercent,project){
    var state=normalize(input,0,20,date);
    var moved=Math.min(state.available,money(amount));
    var selectedMode=mode==='donation'||mode==='mixed'?mode:'savings';
    var percent=selectedMode==='donation'?100:selectedMode==='mixed'?Math.min(100,Math.max(0,Number(donationPercent)||0)):0;
    var donated=money(moved*percent/100),locked=money(moved-donated),months=Math.max(1,Number(project&&project.lockMonths)||Number(lockMonths)||1);
    state.available=money(state.available-moved);state.donated=money(state.donated+donated);
    var destination=project&&project.id?{projectId:String(project.id),projectName:String(project.name||'Projet'),unlockFeePercent:5}:{projectId:'',projectName:'',unlockFeePercent:5};
    if(locked)state.lockedEntries.push({id:'lock-'+dayKey(date)+'-'+String(state.transactions.length+1),amount:locked,lockedAt:dayKey(date),unlockAt:dayKey(addMonths(date,months)),projectId:destination.projectId,projectName:destination.projectName,unlockFeePercent:destination.unlockFeePercent});
    state.locked=money(state.lockedEntries.reduce(function(sum,entry){return sum+entry.amount;},0));
    var label=selectedMode==='donation'?'Oubli · don simulé':selectedMode==='mixed'?'Oubli · '+donated.toFixed(2)+' € donnés et '+locked.toFixed(2)+' € bloqués':'Oubli · '+(destination.projectName?'projet « '+destination.projectName+' »':'réserve '+months+' mois');
    addTransaction(state,{date:dayKey(date),type:selectedMode==='donation'?'donation':selectedMode==='mixed'?'mixed':'lock',amount:moved,locked:locked,donated:donated,projectId:destination.projectId,projectName:destination.projectName,label:label});
    return state;
  }

  function recordScan(input,date){var state=normalize(input,0,20,date);addTransaction(state,{date:dayKey(date),type:'scan',amount:0,label:'Scan Déclic validé'});return state;}

  function topUp(input,date){
    var state=normalize(input,0,20,date),added=money(Math.max(0,state.target-state.available));
    state.available=money(state.available+added);
    if(added)addTransaction(state,{date:dayKey(date),type:'topup',amount:added,label:'Remplissage automatique simulé'});
    return state;
  }

  function lockedBreakdown(input,date){
    var state=normalize(input,0,20,date),key=dayKey(date||new Date()),matured=0,early=0,earlyFee=0,nextUnlockAt='';
    state.lockedEntries.forEach(function(entry){if(entry.unlockAt<=key)matured+=entry.amount;else{early+=entry.amount;earlyFee+=entry.amount*5/100;if(!nextUnlockAt||entry.unlockAt<nextUnlockAt)nextUnlockAt=entry.unlockAt;}});
    return {matured:money(matured),early:money(early),earlyFee:money(earlyFee),nextUnlockAt:nextUnlockAt};
  }

  function projectBreakdown(input){
    var state=normalize(input,0,20,new Date()),projects={};
    state.lockedEntries.forEach(function(entry){
      if(!entry.projectId)return;
      if(!projects[entry.projectId])projects[entry.projectId]={id:entry.projectId,name:entry.projectName||'Projet',amount:0};
      projects[entry.projectId].amount=money(projects[entry.projectId].amount+entry.amount);
    });
    return Object.keys(projects).map(function(id){return projects[id];});
  }

  function unlock(input,date,feePercent,includeEarly){
    var state=normalize(input,0,20,date),key=dayKey(date||new Date()),rate=Math.min(100,Math.max(0,Number(feePercent)||0)),kept=[],matured=0,early=0,feeRaw=0;
    state.lockedEntries.forEach(function(entry){if(entry.unlockAt<=key)matured+=entry.amount;else if(includeEarly){early+=entry.amount;var entryRate=5;feeRaw+=entry.amount*entryRate/100;}else kept.push(entry);});
    matured=money(matured);early=money(early);
    var fee=money(feeRaw),released=money(matured+early-fee);
    state.available=money(state.available+released);state.feesPaid=money(state.feesPaid+fee);state.lockedEntries=kept;state.locked=money(kept.reduce(function(sum,entry){return sum+entry.amount;},0));
    if(matured||early)addTransaction(state,{date:key,type:'unlock',amount:released,fee:fee,label:early?'Déblocage anticipé · '+fee.toFixed(2)+' € de frais simulés':'Déblocage arrivé à échéance · sans frais'});
    return state;
  }

  return {dayKey:dayKey,previousDayKey:previousDayKey,addMonths:addMonths,create:create,normalize:normalize,recordFailure:recordFailure,recordScan:recordScan,topUp:topUp,lockedBreakdown:lockedBreakdown,projectBreakdown:projectBreakdown,unlock:unlock};
});
