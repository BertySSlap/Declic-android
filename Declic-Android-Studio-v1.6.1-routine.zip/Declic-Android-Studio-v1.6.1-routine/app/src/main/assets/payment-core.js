(function(root,factory){
  var api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.DeclicPaymentCore=api;
})(typeof self!=='undefined'?self:this,function(){
  'use strict';

  function numberBetween(value,min,max,fallback){
    var parsed=Number(value);
    if(!Number.isFinite(parsed))parsed=fallback;
    return Math.min(max,Math.max(min,Math.round(parsed)));
  }

  function lastFour(raw){
    var digits=String(raw||'').replace(/\D/g,'');
    return digits.length>=4?digits.slice(-4):'';
  }

  function luhnValid(raw){
    var digits=String(raw||'').replace(/\D/g,'');
    if(digits.length<13||digits.length>19||/^(\d)\1+$/.test(digits))return false;
    var sum=0;
    var doubleDigit=false;
    for(var index=digits.length-1;index>=0;index--){
      var digit=Number(digits.charAt(index));
      if(doubleDigit){digit*=2;if(digit>9)digit-=9;}
      sum+=digit;
      doubleDigit=!doubleDigit;
    }
    return sum%10===0;
  }

  function comparableName(value){
    var plain=String(value||'').trim().toLowerCase();
    if(plain.normalize)plain=plain.normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    return plain.replace(/[^a-z0-9]+/g,' ').trim().split(/\s+/).filter(Boolean).sort().join(' ');
  }

  function normalize(input){
    var source=input&&typeof input==='object'?input:{};
    var target=numberBetween(source.potTarget,5,1000,40);
    var threshold=numberBetween(source.threshold,2,Math.max(2,target-1),Math.min(10,target-1));
    return {
      cardholder:String(source.cardholder||'').trim().slice(0,80),
      last4:lastFour(source.cardNumber||source.last4),
      potTarget:target,
      threshold:threshold
    };
  }

  function validate(input,existing){
    var source=input&&typeof input==='object'?input:{};
    var current=normalize(existing);
    var digits=String(source.cardNumber||'').replace(/\D/g,'');
    var target=Number(source.potTarget);
    var threshold=Number(source.threshold);
    var errors={};
    var holder=String(source.cardholder||current.cardholder).trim();
    if(!holder)errors.cardholder='Indique le titulaire de la carte.';
    else if(holder.split(/\s+/).length<2)errors.cardholder='Indique le prénom et le nom du titulaire.';
    else if(source.expectedCardholder&&comparableName(holder)!==comparableName(source.expectedCardholder))errors.cardholder='Le titulaire doit correspondre au prénom et au nom du compte.';
    if(!digits&&!current.last4)errors.cardNumber='Indique un numéro de carte.';
    else if(digits&&!luhnValid(digits))errors.cardNumber='Ce numéro de carte n’est pas valide.';
    if(!Number.isFinite(target)||target<5||target>1000)errors.potTarget='Le montant cible doit être compris entre 5 € et 1 000 €.';
    if(!Number.isFinite(threshold)||threshold<2)errors.threshold='Le seuil « À partir de » doit être d’au moins 2 €.';
    else if(Number.isFinite(target)&&threshold>=target)errors.threshold='Le montant cible doit être supérieur au seuil « À partir de ».';
    var fields=Object.keys(errors);
    if(fields.length)return {ok:false,field:fields[0],message:errors[fields[0]],errors:errors};
    var normalized=normalize({
      cardholder:source.cardholder||current.cardholder,
      cardNumber:digits||current.last4,
      potTarget:source.potTarget,
      threshold:source.threshold
    });
    return {ok:true,value:normalized};
  }

  return {lastFour:lastFour,luhnValid:luhnValid,comparableName:comparableName,normalize:normalize,validate:validate};
});
