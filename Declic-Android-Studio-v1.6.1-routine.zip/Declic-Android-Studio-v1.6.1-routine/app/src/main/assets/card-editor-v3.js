/* Card editor: 3 selected visuals, 3 persistent imported SVGs and one undo transaction per action. */
(() => {
  'use strict';
  const core=window.DeclicEditorCore,cards=[...document.querySelectorAll('.custom-card-preview')];
  const front=document.getElementById('customCardFront'),nameInput=document.getElementById('customCardName'),sloganInput=document.getElementById('customCardSlogan');
  const namePreview=document.getElementById('customCardNamePreview'),sloganPreview=document.getElementById('customCardSloganPreview');
  const visualEls=[document.getElementById('customCardArtPreview')];
  for(let i=1;i<3;i++){
    const el=document.createElement('div');el.className='custom-card-art hidden';el.dataset.cardElement='visual-'+i;
    front.appendChild(el);visualEls.push(el);
  }
  visualEls[0].dataset.cardElement='visual-0';
  sloganPreview.dataset.cardElement='slogan';
  const elements=[...document.querySelectorAll('[data-card-element]')];
  const done=document.getElementById('finishCardEdit'),undo=document.getElementById('undoCardEdit'),help=document.getElementById('cardEditHelp');
  const upload=document.getElementById('customSvgUpload'),importedList=document.getElementById('importedSvgList');
  const library=document.getElementById('visualLibrary'),openLibrary=document.getElementById('openVisualLibrary'),icons=window.DeclicIcons;
  const selectionStatus=document.getElementById('visualSelectionStatus'),states=new Map(),pointers=new Map(),guides=new Map();
  let editing=false,selected=null,hold=null,drag=null,multi=null,transaction=null,textBefore=null,history=[],savedLayout={};
  let design={name:nameInput.value,slogan:sloganInput.value,visuals:['icon:route'],imports:[]};
  try{savedLayout=JSON.parse(localStorage.getItem('declic.cardLayout')||'{}')||{};}catch(_error){}

  function importId(){return 'svg-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,7);}
  function sanitizeSvg(text){
    if(text.length>1024*1024||/<!DOCTYPE|<!ENTITY/i.test(text))throw new Error('SVG trop volumineux ou incompatible');
    const doc=new DOMParser().parseFromString(text,'image/svg+xml'),root=doc.documentElement;
    if(doc.querySelector('parsererror')||root.localName!=='svg')throw new Error('Fichier SVG invalide');
    [...root.querySelectorAll('*')].filter(el=>el.localName==='metadata'||el.localName==='namedview').forEach(el=>el.remove());
    const tags=new Set(['svg','g','path','circle','ellipse','rect','line','polyline','polygon','defs','linearGradient','radialGradient','stop','clipPath','mask','use','text','tspan','title','desc','style']);
    function safeReferences(value){
      if(/javascript:|@import|expression\s*\(/i.test(value))throw new Error('Le SVG contient des éléments actifs');
      const urls=value.match(/url\s*\([^)]*\)/gi)||[];
      urls.forEach(url=>{const target=url.slice(url.indexOf('(')+1,-1).trim().replace(/^['"]|['"]$/g,'');if(!/^#[A-Za-z_][\w:.-]*$/.test(target))throw new Error('Les ressources externes ne sont pas acceptées');});
    }
    [root,...root.querySelectorAll('*')].forEach(el=>{
      if(!tags.has(el.localName))throw new Error('SVG non statique : élément '+el.localName+' non accepté');
      if(el.localName==='style')safeReferences(el.textContent);
      [...el.attributes].forEach(attr=>{const name=attr.name.toLowerCase(),value=attr.value;if(/^on/.test(name))throw new Error('Le SVG contient des éléments actifs');safeReferences(value);if((name==='href'||name==='xlink:href')&&!/^#[A-Za-z_][\w:.-]*$/.test(value))throw new Error('Les liens externes ne sont pas acceptés');});
    });
    if(!root.hasAttribute('viewBox'))root.setAttribute('viewBox','0 0 '+(parseFloat(root.getAttribute('width'))||100)+' '+(parseFloat(root.getAttribute('height'))||100));
    root.setAttribute('xmlns','http://www.w3.org/2000/svg');root.setAttribute('width','100%');root.setAttribute('height','100%');return new XMLSerializer().serializeToString(root);
  }
  function validImport(value,index){
    if(!value||typeof value.svg!=='string'||typeof value.name!=='string')return null;
    try{return {id:typeof value.id==='string'?value.id:'legacy-'+index,name:value.name.slice(0,90),svg:sanitizeSvg(value.svg)};}catch(_error){return null;}
  }
  try{
    const cached=JSON.parse(localStorage.getItem('declic.cardDesign')||'null');
    if(cached&&typeof cached.name==='string'&&typeof cached.slogan==='string'){
      design.name=cached.name;design.slogan=cached.slogan;
      design.imports=(Array.isArray(cached.imports)?cached.imports:[]).map(validImport).filter(Boolean).slice(0,3);
      if(Array.isArray(cached.visuals))design.visuals=cached.visuals.filter(ref=>typeof ref==='string').slice(0,3);
      else{
        design.visuals=[];
        if(cached.visual!=='none')design.visuals.push('icon:'+(icons.some(icon=>icon.id===cached.visual)?cached.visual:'route'));
        design.imports.forEach(item=>{if(design.visuals.length<3)design.visuals.push('import:'+item.id);});
      }
    }
  }catch(_error){}
  function visualFor(ref){
    if(/^icon:/.test(ref)){const icon=icons.find(item=>item.id===ref.slice(5));return icon?{ref,name:icon.name,svg:icon.svg}:null;}
    if(/^import:/.test(ref)){const item=design.imports.find(value=>value.id===ref.slice(7));return item?{ref,name:item.name,svg:item.svg}:null;}
    return null;
  }
  design.visuals=design.visuals.filter(ref=>visualFor(ref)).filter((ref,index,list)=>list.indexOf(ref)===index).slice(0,3);
  if(savedLayout.art&&!savedLayout['visual-0'])savedLayout['visual-0']=savedLayout.art;
  if(savedLayout['import-0']&&!savedLayout['visual-1'])savedLayout['visual-1']=savedLayout['import-0'];
  if(savedLayout['import-1']&&!savedLayout['visual-2'])savedLayout['visual-2']=savedLayout['import-1'];
  elements.forEach(el=>states.set(el,core.normalize(el.dataset.cardElement,savedLayout[el.dataset.cardElement])));
  cards.forEach(card=>{
    const x=document.createElement('div'),y=document.createElement('div'),angle=document.createElement('div');
    x.className='card-guide card-guide-x';y.className='card-guide card-guide-y';angle.className='card-angle-label hidden';
    card.appendChild(x);card.appendChild(y);card.appendChild(angle);guides.set(card,{x,y,angle});
  });
  const svgFilter=document.createElementNS('http://www.w3.org/2000/svg','svg');
  svgFilter.setAttribute('width','0');svgFilter.setAttribute('height','0');svgFilter.setAttribute('aria-hidden','true');svgFilter.style.position='absolute';
  svgFilter.innerHTML='<defs><filter id="declic-emoji-outline" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB"><feMorphology in="SourceAlpha" operator="erode" radius="0.7" result="inner"/><feComposite in="SourceAlpha" in2="inner" operator="out" result="edge"/><feFlood flood-color="#000"/><feComposite in2="edge" operator="in"/></filter></defs>';
  document.body.appendChild(svgFilter);
  let emojiPattern;
  try{emojiPattern=new RegExp('(?:\\p{Regional_Indicator}{2}|[0-9#*]\\uFE0F?\\u20E3|\\p{Extended_Pictographic}[\\uFE0F\\uFE0E]?\\p{Emoji_Modifier}?(?:\\u200D\\p{Extended_Pictographic}[\\uFE0F\\uFE0E]?\\p{Emoji_Modifier}?)*)','gu');}
  catch(_error){emojiPattern=/[\u2600-\u27BF\uD800-\uDFFF][\uFE0F\uFE0E\uD800-\uDFFF]*/g;}
  function monochromeText(el,value){
    el.textContent='';let last=0,match;emojiPattern.lastIndex=0;
    while((match=emojiPattern.exec(value))){el.appendChild(document.createTextNode(value.slice(last,match.index)));const span=document.createElement('span');span.className='mono-emoji';span.textContent=match[0];el.appendChild(span);last=match.index+match[0].length;}
    el.appendChild(document.createTextNode(value.slice(last)));
  }
  function renderText(){monochromeText(namePreview,nameInput.value.trim());monochromeText(sloganPreview,sloganInput.value);}
  function snapshot(){const layout={};states.forEach((state,el)=>layout[el.dataset.cardElement]={...state});return {layout,name:nameInput.value,slogan:sloganInput.value,visuals:design.visuals.slice(),imports:design.imports.map(item=>({...item}))};}
  function remember(before){if(!before||JSON.stringify(before)===JSON.stringify(snapshot()))return;history.push(before);if(history.length>24)history.shift();undo.disabled=false;}
  function persist(){
    const value=snapshot();design.name=value.name;design.slogan=value.slogan;
    try{localStorage.setItem('declic.cardLayout',JSON.stringify(value.layout));localStorage.setItem('declic.cardDesign',JSON.stringify(design));}
    catch(_error){toast('Stockage plein : supprime un SVG importé avant de continuer.');}
  }
  function render(el){const card=el.closest('.custom-card-preview'),state=states.get(el);if(card&&card.clientWidth)el.style.transform=`translate(${state.x*card.clientWidth}px,${state.y*card.clientHeight}px) rotate(${state.rotation}deg) scale(${state.scale})`;}
  function constrain(el){
    const card=el.closest('.custom-card-preview');if(!card||!card.clientWidth||el.classList.contains('hidden'))return;
    const state=states.get(el),id=el.dataset.cardElement,isQr=/-qr$/.test(id),resizable=isQr||/^visual-/.test(id),min=isQr?1:.15,pad=5;
    if(resizable){const box=core.rotatedSize(el.offsetWidth,el.offsetHeight,state.rotation);const max=Math.max(min,Math.min(4,(card.clientWidth-pad*2)/Math.max(1,box.width),(card.clientHeight-pad*2)/Math.max(1,box.height)));state.scale=core.clamp(state.scale,min,max);}else state.scale=1;
    render(el);const cardBox=card.getBoundingClientRect(),box=el.getBoundingClientRect();
    const dx=box.width>cardBox.width-pad*2?cardBox.left+cardBox.width/2-box.left-box.width/2:Math.max(cardBox.left+pad-box.left,Math.min(0,cardBox.right-pad-box.right));
    const dy=box.height>cardBox.height-pad*2?cardBox.top+cardBox.height/2-box.top-box.height/2:Math.max(cardBox.top+pad-box.top,Math.min(0,cardBox.bottom-pad-box.bottom));
    state.x+=dx/card.clientWidth;state.y+=dy/card.clientHeight;render(el);
  }
  function hideGuides(){guides.forEach(guide=>{guide.x.style.display=guide.y.style.display='none';guide.angle.classList.add('hidden');});}
  function align(el){
    hideGuides();const card=el.closest('.custom-card-preview'),cardBox=card.getBoundingClientRect(),box=el.getBoundingClientRect();
    const xs=[cardBox.left+6,cardBox.left+cardBox.width/2,cardBox.right-6],ys=[cardBox.top+6,cardBox.top+cardBox.height/2,cardBox.bottom-6];
    [...card.querySelectorAll('[data-card-element],.fixed-logo,.custom-card-back-copy')].forEach(other=>{if(other===el||other.classList.contains('hidden'))return;const otherBox=other.getBoundingClientRect();xs.push(otherBox.left,otherBox.left+otherBox.width/2,otherBox.right);ys.push(otherBox.top,otherBox.top+otherBox.height/2,otherBox.bottom);});
    const x=core.nearest([box.left,box.left+box.width/2,box.right],xs,4),y=core.nearest([box.top,box.top+box.height/2,box.bottom],ys,4),state=states.get(el),guide=guides.get(card);
    if(x){state.x+=x.delta/card.clientWidth;guide.x.style.left=(x.target-cardBox.left)+'px';guide.x.style.display='block';}
    if(y){state.y+=y.delta/card.clientHeight;guide.y.style.top=(y.target-cardBox.top)+'px';guide.y.style.display='block';}constrain(el);
  }
  function refreshSize(){cards.forEach(card=>{if(card.clientWidth)card.style.fontSize=(card.clientWidth/194)+'px';});elements.forEach(constrain);}
  function selectedNames(){return design.visuals.map(visualFor).filter(Boolean).map(item=>item.name);}
  function renderImportedLibrary(){
    importedList.textContent='';
    if(!design.imports.length){const empty=document.createElement('div');empty.className='small';empty.textContent='Aucun SVG importé.';importedList.appendChild(empty);return;}
    design.imports.forEach(item=>{
      const ref='import:'+item.id,row=document.createElement('div');row.className='imported-svg-row';row.classList.toggle('selected',design.visuals.includes(ref));
      const choose=document.createElement('button');choose.type='button';choose.className='imported-svg-select';choose.innerHTML=item.svg;
      const label=document.createElement('span');label.textContent=item.name;choose.appendChild(label);choose.setAttribute('aria-label','Ajouter ou retirer '+item.name);choose.addEventListener('click',()=>toggleVisual(ref));
      const remove=document.createElement('button');remove.type='button';remove.className='imported-svg-delete';remove.textContent='×';remove.setAttribute('aria-label','Supprimer '+item.name+' de la bibliothèque');
      remove.addEventListener('click',()=>{const before=snapshot();design.imports=design.imports.filter(value=>value.id!==item.id);design.visuals=design.visuals.filter(value=>value!==ref);renderDesign();remember(before);persist();toast(item.name+' supprimé de la bibliothèque');});
      row.appendChild(choose);row.appendChild(remove);importedList.appendChild(row);
    });
  }
  function renderDesign(){
    nameInput.value=design.name;sloganInput.value=design.slogan;renderText();
    visualEls.forEach((el,index)=>{const item=visualFor(design.visuals[index]);el.innerHTML=item?item.svg:'';el.classList.toggle('hidden',!item);el.setAttribute('aria-label',item?item.name:'Emplacement de visuel vide');});
    document.querySelectorAll('[data-visual]').forEach(button=>{const ref='icon:'+button.dataset.visual;button.classList.toggle('active',button.dataset.visual==='none'?!design.visuals.length:design.visuals.includes(ref));});
    const names=selectedNames(),count=names.length;selectionStatus.innerHTML='<strong>'+count+'/3 visuel'+(count>1?'s':'')+' sélectionné'+(count>1?'s':'')+'</strong>'+(names.length?' · '+names.join(', '):' · Aucun visuel sur la carte.');
    document.querySelectorAll('#iconLibraryGrid [data-visual]').forEach(button=>button.classList.toggle('active',design.visuals.includes('icon:'+button.dataset.visual)));
    renderImportedLibrary();upload.disabled=design.imports.length>=3;refreshSize();
  }
  function select(el){selected=el;elements.forEach(item=>item.classList.toggle('element-selected',item===el));}
  function enable(){editing=true;cards.forEach(card=>card.classList.add('editing'));done.classList.remove('hidden');help.textContent='Glisse un élément pour le déplacer. Deux doigts : tourner ; pincer pour agrandir les visuels et QR. Les lignes bleues aident à aligner.';}
  function clearHold(){clearTimeout(hold);hold=null;}
  function commit(){remember(transaction);transaction=null;persist();}
  function stop(){clearHold();if(transaction)commit();pointers.clear();drag=multi=null;editing=false;select(null);hideGuides();cards.forEach(card=>card.classList.remove('editing'));done.classList.add('hidden');help.textContent='Modifications enregistrées. Appui long pour déplacer, tourner et redimensionner. Les QR ne peuvent pas être plus petits que le modèle.';}
  function restore(value){design={name:value.name,slogan:value.slogan,visuals:(value.visuals||['icon:'+(value.visual||'route')]).slice(0,3),imports:(value.imports||[]).map(item=>({...item}))};elements.forEach(el=>states.set(el,core.normalize(el.dataset.cardElement,value.layout[el.dataset.cardElement])));renderDesign();persist();}
  function pair(){const pairValues=[...pointers.values()],a=pairValues[0],b=pairValues[1];return a&&b?{distance:Math.max(1,Math.hypot(b.x-a.x,b.y-a.y)),angle:core.angle(a,b),x:(a.x+b.x)/2,y:(a.y+b.y)/2}:null;}
  cards.forEach(card=>{
    card.addEventListener('contextmenu',event=>event.preventDefault());card.addEventListener('dragstart',event=>event.preventDefault());
    card.addEventListener('pointerdown',event=>{
      if(event.pointerType==='mouse'&&event.button!==0)return;event.preventDefault();card.setPointerCapture(event.pointerId);pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
      const target=event.target.closest('[data-card-element]');
      if(pointers.size===2){clearHold();drag=null;if(editing&&selected&&card.contains(selected)){if(!transaction)transaction=snapshot();multi={...pair(),initial:{...states.get(selected)}};}return;}
      if(pointers.size!==1)return;const start={x:event.clientX,y:event.clientY};clearHold();
      const begin=()=>{enable();select(target);hold=null;if(target){transaction=snapshot();drag={id:event.pointerId,start,initial:{...states.get(target)}};}};
      if(editing)begin();else{drag={pending:true,id:event.pointerId,start};hold=setTimeout(begin,450);}
    });
    card.addEventListener('pointermove',event=>{
      if(!pointers.has(event.pointerId))return;event.preventDefault();pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
      if(multi&&selected&&pointers.size===2){const current=pair(),state=states.get(selected),id=selected.dataset.cardElement;state.rotation=multi.initial.rotation+core.deltaAngle(multi.angle,current.angle);const snap=Math.round(state.rotation/90)*90;if(Math.abs(state.rotation-snap)<3)state.rotation=snap;if(/^visual-/.test(id)||/-qr$/.test(id))state.scale=multi.initial.scale*current.distance/multi.distance;state.x=multi.initial.x+(current.x-multi.x)/card.clientWidth;state.y=multi.initial.y+(current.y-multi.y)/card.clientHeight;constrain(selected);align(selected);const guide=guides.get(card);guide.angle.textContent=Math.round(state.rotation)+'°';guide.angle.classList.remove('hidden');return;}
      if(!drag||drag.id!==event.pointerId)return;const dx=event.clientX-drag.start.x,dy=event.clientY-drag.start.y;if(drag.pending){if(Math.hypot(dx,dy)>10){clearHold();drag=null;}return;}if(!selected)return;const state=states.get(selected);state.x=drag.initial.x+dx/card.clientWidth;state.y=drag.initial.y+dy/card.clientHeight;constrain(selected);align(selected);
    });
    function release(event){if(!pointers.has(event.pointerId))return;pointers.delete(event.pointerId);clearHold();multi=null;hideGuides();if(pointers.size===1&&editing&&selected){const remaining=[...pointers.entries()][0];drag={id:remaining[0],start:remaining[1],initial:{...states.get(selected)}};}else{drag=null;if(!pointers.size&&transaction)commit();}}
    card.addEventListener('pointerup',release);card.addEventListener('lostpointercapture',release);card.addEventListener('pointercancel',()=>{clearHold();pointers.clear();drag=multi=null;hideGuides();if(transaction){const before=transaction;transaction=null;restore(before);}});
  });
  done.addEventListener('click',stop);
  document.getElementById('resetCardLayout').addEventListener('click',()=>{stop();const before=snapshot();states.forEach((state,el)=>states.set(el,core.normalize(el.dataset.cardElement,{})));renderDesign();remember(before);persist();help.textContent='Disposition du modèle rétablie. Nom, slogan, visuels et bibliothèque SVG conservés.';});
  undo.addEventListener('click',()=>{if(transaction)commit();const value=history.pop();if(!value)return;stop();restore(value);undo.disabled=!history.length;textBefore=null;help.textContent='Action précédente rétablie.';});
  [nameInput,sloganInput].forEach(input=>{input.addEventListener('focus',()=>{textBefore=snapshot();});input.addEventListener('input',()=>{renderText();refreshSize();if(textBefore){remember(textBefore);textBefore=null;}persist();});input.addEventListener('blur',()=>{textBefore=null;persist();});});
  function toggleVisual(ref){
    const before=snapshot(),index=design.visuals.indexOf(ref);
    if(index>=0)design.visuals.splice(index,1);
    else if(design.visuals.length>=3){toast('Trois visuels maximum peuvent être placés sur la carte.');return;}
    else design.visuals.push(ref);
    renderDesign();remember(before);persist();
  }
  const grid=document.getElementById('iconLibraryGrid');
  icons.forEach(icon=>{const button=document.createElement('button');button.type='button';button.dataset.visual=icon.id;button.innerHTML=icon.svg;const label=document.createElement('span');label.textContent=icon.name;button.appendChild(label);button.setAttribute('aria-label',icon.name);button.addEventListener('click',()=>toggleVisual('icon:'+icon.id));grid.appendChild(button);});
  document.querySelectorAll('#visualBank [data-visual]').forEach(button=>{const icon=icons.find(value=>value.id===button.dataset.visual);if(icon)button.innerHTML=icon.svg;button.addEventListener('click',()=>{if(button.dataset.visual==='none'){const before=snapshot();design.visuals=[];renderDesign();remember(before);persist();}else toggleVisual('icon:'+button.dataset.visual);});});
  openLibrary.addEventListener('click',()=>{const visible=library.classList.contains('hidden');library.classList.toggle('hidden',!visible);openLibrary.setAttribute('aria-expanded',String(visible));});
  document.getElementById('closeVisualLibrary').addEventListener('click',()=>{library.classList.add('hidden');openLibrary.setAttribute('aria-expanded','false');});
  function readFile(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Lecture impossible : '+file.name));reader.readAsText(file);});}
  upload.addEventListener('change',async()=>{
    const files=[...(upload.files||[])];if(!files.length)return;const free=3-design.imports.length;
    if(files.length>free){toast('La bibliothèque accepte trois SVG maximum. Supprime un SVG avant d’en ajouter.');upload.value='';return;}
    upload.disabled=true;undo.disabled=true;
    try{
      const loaded=[];for(const file of files){if(!/\.svg$/i.test(file.name)||file.size>1024*1024)throw new Error('Choisis un SVG de moins de 1 Mo');loaded.push({id:importId(),name:file.name,svg:sanitizeSvg(await readFile(file))});}
      const before=snapshot();design.imports=design.imports.concat(loaded).slice(0,3);loaded.forEach(item=>{if(design.visuals.length<3)design.visuals.push('import:'+item.id);});renderDesign();remember(before);persist();toast(loaded.length+' SVG ajouté'+(loaded.length>1?'s':'')+' à la bibliothèque');
    }catch(error){toast(error.message||'Impossible d’importer ce fichier');}
    finally{upload.value='';upload.disabled=design.imports.length>=3;undo.disabled=!history.length;}
  });
  document.querySelectorAll('.custom-card-tabs button').forEach(button=>button.addEventListener('click',()=>{stop();refreshSize();}));
  document.querySelectorAll('[data-go="card-customize"]').forEach(button=>button.addEventListener('click',refreshSize));window.addEventListener('resize',refreshSize);
  if(typeof ResizeObserver!=='undefined'){const observer=new ResizeObserver(refreshSize);cards.forEach(card=>observer.observe(card));}
  window.DeclicCardEditor={renderText,refreshSize,getOrderDesign:()=>snapshot()};renderDesign();stop();
})();
