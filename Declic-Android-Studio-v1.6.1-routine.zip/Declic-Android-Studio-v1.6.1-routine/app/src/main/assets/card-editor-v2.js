/* One undo transaction per gesture, imported batch or text edit. */
(() => {
  'use strict';
  const core=window.DeclicEditorCore,cards=[...document.querySelectorAll('.custom-card-preview')];
  const front=document.getElementById('customCardFront'),art=document.getElementById('customCardArtPreview');
  const nameInput=document.getElementById('customCardName'),sloganInput=document.getElementById('customCardSlogan');
  const namePreview=document.getElementById('customCardNamePreview'),sloganPreview=document.getElementById('customCardSloganPreview');
  art.dataset.cardElement='art';sloganPreview.dataset.cardElement='slogan';
  const importedEls=[];
  for(let i=0;i<3;i++){
    const el=document.createElement('div');el.className='custom-card-import hidden';el.dataset.cardElement='import-'+i;
    el.style.left=(24+i*12)+'%';el.style.top=(25+i*10)+'%';front.appendChild(el);importedEls.push(el);
  }
  const elements=[...document.querySelectorAll('[data-card-element]')];
  const done=document.getElementById('finishCardEdit'),undo=document.getElementById('undoCardEdit');
  const help=document.getElementById('cardEditHelp'),upload=document.getElementById('customSvgUpload');
  const importedList=document.getElementById('importedSvgList');
  const library=document.getElementById('visualLibrary'),openLibrary=document.getElementById('openVisualLibrary'),icons=window.DeclicIcons;
  const states=new Map(),pointers=new Map(),guides=new Map();
  let editing=false,selected=null,hold=null,drag=null,multi=null,transaction=null,textBefore=null;
  let history=[],savedLayout={},design={name:nameInput.value,slogan:sloganInput.value,visual:'route',imports:[null,null,null]};
  try{savedLayout=JSON.parse(localStorage.getItem('declic.cardLayout')||'{}')||{};}catch(_){}
  // Validate cached imports too: storage is not trusted executable content.
  try{
    const d=JSON.parse(localStorage.getItem('declic.cardDesign')||'null');
    if(d&&typeof d.name==='string'&&typeof d.slogan==='string'){
      design.name=d.name;design.slogan=d.slogan;
      design.visual=d.visual==='none'||icons.some(icon=>icon.id===d.visual)?d.visual:'route';
      if(Array.isArray(d.imports))design.imports=[0,1,2].map(i=>{
        const v=d.imports[i];if(!v||typeof v.svg!=='string'||typeof v.name!=='string')return null;
        try{return {name:v.name,svg:sanitizeSvg(v.svg)};}catch(_){return null;}
      });
    }
  }catch(_){}
  elements.forEach(el=>states.set(el,core.normalize(el.dataset.cardElement,savedLayout[el.dataset.cardElement])));
  cards.forEach(card=>{
    const x=document.createElement('div'),y=document.createElement('div'),angle=document.createElement('div');
    x.className='card-guide card-guide-x';y.className='card-guide card-guide-y';angle.className='card-angle-label hidden';
    card.appendChild(x);card.appendChild(y);card.appendChild(angle);guides.set(card,{x,y,angle});
  });
  const svgFilter=document.createElementNS('http://www.w3.org/2000/svg','svg');
  svgFilter.setAttribute('width','0');svgFilter.setAttribute('height','0');svgFilter.setAttribute('aria-hidden','true');svgFilter.style.position='absolute';
  svgFilter.innerHTML='<defs><filter id="declic-emoji-outline" x="-10%" y="-10%" width="120%" height="120%" color-interpolation-filters="sRGB"><feMorphology in="SourceAlpha" operator="erode" radius="0.7" result="inner"/><feComposite in="SourceAlpha" in2="inner" operator="out" result="edge"/><feFlood flood-color="#000"/><feComposite in2="edge" operator="in"/></filter></defs>';
  document.body.appendChild(svgFilter);
  let emojiPattern;
  try{emojiPattern=new RegExp('(?:\\p{Regional_Indicator}{2}|[0-9#*]\\uFE0F?\\u20E3|\\p{Extended_Pictographic}[\\uFE0F\\uFE0E]?\\p{Emoji_Modifier}?(?:\\u200D\\p{Extended_Pictographic}[\\uFE0F\\uFE0E]?\\p{Emoji_Modifier}?)*)','gu');}
  catch(_){emojiPattern=/[\u2600-\u27BF\uD800-\uDFFF][\uFE0F\uFE0E\uD800-\uDFFF]*/g;}
  function monochromeText(el,value){
    el.textContent='';let last=0,match;emojiPattern.lastIndex=0;
    while((match=emojiPattern.exec(value))){
      el.appendChild(document.createTextNode(value.slice(last,match.index)));
      const span=document.createElement('span');span.className='mono-emoji';span.textContent=match[0];el.appendChild(span);last=match.index+match[0].length;
    }el.appendChild(document.createTextNode(value.slice(last)));
  }
  function renderText(){monochromeText(namePreview,nameInput.value.trim());monochromeText(sloganPreview,sloganInput.value);}
  function snapshot(){
    const layout={};states.forEach((s,el)=>layout[el.dataset.cardElement]={...s});
    return {layout,name:nameInput.value,slogan:sloganInput.value,visual:design.visual,imports:design.imports.slice()};
  }
  function remember(before){
    if(!before||JSON.stringify(before)===JSON.stringify(snapshot()))return;
    history.push(before);if(history.length>24)history.shift();undo.disabled=false;
  }
  function persist(){
    const value=snapshot();design.name=value.name;design.slogan=value.slogan;
    try{localStorage.setItem('declic.cardLayout',JSON.stringify(value.layout));localStorage.setItem('declic.cardDesign',JSON.stringify(design));}
    catch(_){toast('Stockage plein : modifications conservées uniquement pendant cette session.');}
  }
  function render(el){
    const card=el.closest('.custom-card-preview'),s=states.get(el);if(!card.clientWidth)return;
    el.style.transform=`translate(${s.x*card.clientWidth}px,${s.y*card.clientHeight}px) rotate(${s.rotation}deg) scale(${s.scale})`;
  }
  function constrain(el){
    const card=el.closest('.custom-card-preview');if(!card.clientWidth||el.classList.contains('hidden'))return;
    const s=states.get(el),qr=/-qr$/.test(el.dataset.cardElement),resizable=qr||el===art||importedEls.includes(el),min=qr?1:.15,pad=5;
    if(resizable){
      const b=core.rotatedSize(el.offsetWidth,el.offsetHeight,s.rotation);
      const max=Math.max(min,Math.min(4,(card.clientWidth-pad*2)/Math.max(1,b.width),(card.clientHeight-pad*2)/Math.max(1,b.height)));
      s.scale=core.clamp(s.scale,min,max);
    }else s.scale=1;
    render(el);const c=card.getBoundingClientRect(),r=el.getBoundingClientRect();
    const dx=r.width>c.width-pad*2?c.left+c.width/2-r.left-r.width/2:Math.max(c.left+pad-r.left,Math.min(0,c.right-pad-r.right));
    const dy=r.height>c.height-pad*2?c.top+c.height/2-r.top-r.height/2:Math.max(c.top+pad-r.top,Math.min(0,c.bottom-pad-r.bottom));
    s.x+=dx/card.clientWidth;s.y+=dy/card.clientHeight;render(el);
  }
  function hideGuides(){guides.forEach(g=>{g.x.style.display=g.y.style.display='none';g.angle.classList.add('hidden');});}
  function align(el){
    hideGuides();const card=el.closest('.custom-card-preview'),c=card.getBoundingClientRect(),r=el.getBoundingClientRect();
    const xs=[c.left+6,c.left+c.width/2,c.right-6],ys=[c.top+6,c.top+c.height/2,c.bottom-6];
    [...card.querySelectorAll('[data-card-element],.fixed-logo,.custom-card-back-copy')].forEach(other=>{
      if(other===el||other.classList.contains('hidden'))return;
      const b=other.getBoundingClientRect();xs.push(b.left,b.left+b.width/2,b.right);ys.push(b.top,b.top+b.height/2,b.bottom);
    });
    const x=core.nearest([r.left,r.left+r.width/2,r.right],xs,4),y=core.nearest([r.top,r.top+r.height/2,r.bottom],ys,4),s=states.get(el),g=guides.get(card);
    if(x){s.x+=x.delta/card.clientWidth;g.x.style.left=(x.target-c.left)+'px';g.x.style.display='block';}
    if(y){s.y+=y.delta/card.clientHeight;g.y.style.top=(y.target-c.top)+'px';g.y.style.display='block';}constrain(el);
  }
  function refreshSize(){cards.forEach(card=>{if(card.clientWidth)card.style.fontSize=(card.clientWidth/194)+'px';});elements.forEach(constrain);}
  function renderDesign(){
    nameInput.value=design.name;sloganInput.value=design.slogan;renderText();
    const icon=icons.find(v=>v.id===design.visual);art.innerHTML=icon?icon.svg:'';art.classList.toggle('hidden',!icon);
    importedEls.forEach((el,i)=>{
      el.textContent='';const item=design.imports[i];el.classList.toggle('hidden',!item);
      if(item){const image=document.createElement('img');image.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(item.svg);image.alt=item.name;el.appendChild(image);}
    });
    document.querySelectorAll('[data-visual]').forEach(button=>button.classList.toggle('active',button.dataset.visual===design.visual));
    importedList.textContent='';design.imports.forEach((item,i)=>{
      if(!item)return;const row=document.createElement('div');row.className='imported-svg-row';
      const label=document.createElement('span');label.textContent=(i+1)+'. '+item.name;
      const remove=document.createElement('button');remove.type='button';remove.textContent='Retirer';remove.setAttribute('aria-label','Retirer '+item.name);
      remove.addEventListener('click',()=>{const before=snapshot();design.imports[i]=null;renderDesign();remember(before);persist();});
      row.appendChild(label);row.appendChild(remove);importedList.appendChild(row);
    });upload.disabled=design.imports.filter(Boolean).length>=3;refreshSize();
  }
  function select(el){selected=el;elements.forEach(item=>item.classList.toggle('element-selected',item===el));}
  function enable(){
    editing=true;cards.forEach(card=>card.classList.add('editing'));done.classList.remove('hidden');
    help.textContent='Glisse un élément pour le déplacer. Deux doigts : tourner ; pincer pour agrandir les visuels et QR. Les lignes bleues aident à aligner.';
  }
  function clearHold(){clearTimeout(hold);hold=null;}
  function commit(){remember(transaction);transaction=null;persist();}
  function stop(){
    clearHold();if(transaction)commit();pointers.clear();drag=multi=null;editing=false;select(null);hideGuides();
    cards.forEach(card=>card.classList.remove('editing'));done.classList.add('hidden');
    help.textContent='Modifications enregistrées. Appui long pour déplacer, tourner et redimensionner. Les QR ne peuvent pas être plus petits que le modèle.';
  }
  function restore(value){
    design={name:value.name,slogan:value.slogan,visual:value.visual,imports:value.imports.slice()};
    elements.forEach(el=>states.set(el,core.normalize(el.dataset.cardElement,value.layout[el.dataset.cardElement])));renderDesign();persist();
  }
  function pair(){const [a,b]=[...pointers.values()];return a&&b?{distance:Math.max(1,Math.hypot(b.x-a.x,b.y-a.y)),angle:core.angle(a,b),x:(a.x+b.x)/2,y:(a.y+b.y)/2}:null;}
  cards.forEach(card=>{
    card.addEventListener('contextmenu',e=>e.preventDefault());card.addEventListener('dragstart',e=>e.preventDefault());
    card.addEventListener('pointerdown',e=>{
      if(e.pointerType==='mouse'&&e.button!==0)return;
      e.preventDefault();card.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
      const target=e.target.closest('[data-card-element]');
      if(pointers.size===2){clearHold();drag=null;if(editing&&selected&&card.contains(selected)){if(!transaction)transaction=snapshot();multi={...pair(),initial:{...states.get(selected)}};}return;}
      if(pointers.size!==1)return;const start={x:e.clientX,y:e.clientY};clearHold();
      const begin=()=>{enable();select(target);hold=null;if(target){transaction=snapshot();drag={id:e.pointerId,start,initial:{...states.get(target)}};}};
      if(editing)begin();else{drag={pending:true,id:e.pointerId,start};hold=setTimeout(begin,450);}
    });
    card.addEventListener('pointermove',e=>{
      if(!pointers.has(e.pointerId))return;e.preventDefault();pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
      if(multi&&selected&&pointers.size===2){
        const current=pair(),s=states.get(selected),id=selected.dataset.cardElement;
        s.rotation=multi.initial.rotation+core.deltaAngle(multi.angle,current.angle);
        const snap=Math.round(s.rotation/90)*90;if(Math.abs(s.rotation-snap)<3)s.rotation=snap;
        if(id==='art'||/^import-/.test(id)||/-qr$/.test(id))s.scale=multi.initial.scale*current.distance/multi.distance;
        s.x=multi.initial.x+(current.x-multi.x)/card.clientWidth;s.y=multi.initial.y+(current.y-multi.y)/card.clientHeight;
        constrain(selected);align(selected);const g=guides.get(card);g.angle.textContent=Math.round(s.rotation)+'°';g.angle.classList.remove('hidden');return;
      }
      if(!drag||drag.id!==e.pointerId)return;const dx=e.clientX-drag.start.x,dy=e.clientY-drag.start.y;
      if(drag.pending){if(Math.hypot(dx,dy)>10){clearHold();drag=null;}return;}
      if(!selected)return;const s=states.get(selected);s.x=drag.initial.x+dx/card.clientWidth;s.y=drag.initial.y+dy/card.clientHeight;constrain(selected);align(selected);
    });
    function release(e){
      if(!pointers.has(e.pointerId))return;pointers.delete(e.pointerId);clearHold();multi=null;hideGuides();
      if(pointers.size===1&&editing&&selected){const [id,start]=[...pointers.entries()][0];drag={id,start,initial:{...states.get(selected)}};}
      else{drag=null;if(!pointers.size&&transaction)commit();}
    }
    card.addEventListener('pointerup',release);card.addEventListener('lostpointercapture',release);
    card.addEventListener('pointercancel',()=>{clearHold();pointers.clear();drag=multi=null;hideGuides();if(transaction){const before=transaction;transaction=null;restore(before);}});
  });
  done.addEventListener('click',stop);
  document.getElementById('resetCardLayout').addEventListener('click',()=>{
    stop();const before=snapshot();states.forEach((s,el)=>states.set(el,core.normalize(el.dataset.cardElement,{})));renderDesign();remember(before);persist();
    help.textContent='Disposition du modèle rétablie. Nom, slogan, visuel et imports conservés. La flèche de retour permet de revenir en arrière.';
  });
  undo.addEventListener('click',()=>{
    if(transaction)commit();const value=history.pop();if(!value)return;stop();restore(value);undo.disabled=!history.length;textBefore=null;help.textContent='Action précédente rétablie.';
  });
  [nameInput,sloganInput].forEach(input=>{
    input.addEventListener('focus',()=>{textBefore=snapshot();});
    input.addEventListener('input',()=>{renderText();refreshSize();if(textBefore){remember(textBefore);textBefore=null;}persist();});
    input.addEventListener('blur',()=>{textBefore=null;persist();});
  });
  function chooseIcon(id){const before=snapshot();design.name=nameInput.value;design.slogan=sloganInput.value;design.visual=id;renderDesign();remember(before);persist();}
  const grid=document.getElementById('iconLibraryGrid');
  icons.forEach(icon=>{
    const button=document.createElement('button');button.type='button';button.dataset.visual=icon.id;button.innerHTML=icon.svg;
    const label=document.createElement('span');label.textContent=icon.name;button.appendChild(label);button.setAttribute('aria-label',icon.name);grid.appendChild(button);
  });
  document.querySelectorAll('[data-visual]').forEach(button=>{
    const icon=icons.find(value=>value.id===button.dataset.visual);if(button.closest('#visualBank')&&icon)button.innerHTML=icon.svg;
    button.addEventListener('click',()=>chooseIcon(button.dataset.visual));
  });
  openLibrary.addEventListener('click',()=>{const visible=library.classList.contains('hidden');library.classList.toggle('hidden',!visible);openLibrary.setAttribute('aria-expanded',String(visible));});
  document.getElementById('closeVisualLibrary').addEventListener('click',()=>{library.classList.add('hidden');openLibrary.setAttribute('aria-expanded','false');});
  function sanitizeSvg(text){
    if(text.length>1024*1024||/<!DOCTYPE|<!ENTITY/i.test(text))throw new Error('SVG trop volumineux ou incompatible');
    const doc=new DOMParser().parseFromString(text,'image/svg+xml'),root=doc.documentElement;
    if(doc.querySelector('parsererror')||root.localName!=='svg')throw new Error('Fichier SVG invalide');
    [...root.querySelectorAll('*')].filter(el=>el.localName==='metadata'||el.localName==='namedview').forEach(el=>el.remove());
    const tags=new Set(['svg','g','path','circle','ellipse','rect','line','polyline','polygon','defs','linearGradient','radialGradient','stop','clipPath','mask','use','text','tspan','title','desc','style']);
    function safeReferences(value){
      if(/javascript:|@import|expression\s*\(/i.test(value))throw new Error('Le SVG contient des éléments actifs');
      const urls=value.match(/url\s*\([^)]*\)/gi)||[];
      urls.forEach(url=>{
        const target=url.slice(url.indexOf('(')+1,-1).trim().replace(/^['"]|['"]$/g,'');
        if(!/^#[A-Za-z_][\w:.-]*$/.test(target))throw new Error('Les ressources externes ne sont pas acceptées');
      });
    }
    [root,...root.querySelectorAll('*')].forEach(el=>{
      if(!tags.has(el.localName))throw new Error('SVG non statique : élément '+el.localName+' non accepté');
      if(el.localName==='style')safeReferences(el.textContent);
      [...el.attributes].forEach(attr=>{
        const name=attr.name.toLowerCase(),value=attr.value;
        if(/^on/.test(name))throw new Error('Le SVG contient des éléments actifs');
        safeReferences(value);
        if((name==='href'||name==='xlink:href')&&!/^#[A-Za-z_][\w:.-]*$/.test(value))throw new Error('Les liens externes ne sont pas acceptés');
      });
    });
    if(!root.hasAttribute('viewBox'))root.setAttribute('viewBox','0 0 '+(parseFloat(root.getAttribute('width'))||100)+' '+(parseFloat(root.getAttribute('height'))||100));
    root.setAttribute('xmlns','http://www.w3.org/2000/svg');root.setAttribute('width','100%');root.setAttribute('height','100%');return new XMLSerializer().serializeToString(root);
  }
  function readFile(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Lecture impossible : '+file.name));reader.readAsText(file);});}
  upload.addEventListener('change',async()=>{
    const files=[...(upload.files||[])];if(!files.length)return;const free=3-design.imports.filter(Boolean).length;
    if(files.length>free){toast('3 fichiers SVG maximum. Retire un import avant d’en ajouter.');upload.value='';return;}
    upload.disabled=true;undo.disabled=true;
    try{
      const loaded=[];for(const file of files){
        if(!/\.svg$/i.test(file.name)||file.size>1024*1024)throw new Error('Choisis un SVG de moins de 1 Mo');
        loaded.push({name:file.name,svg:sanitizeSvg(await readFile(file))});
      }
      const before=snapshot();loaded.forEach(item=>{const index=design.imports.indexOf(null);design.imports[index]=item;states.set(importedEls[index],core.normalize('import-'+index,{}));});
      design.name=nameInput.value;design.slogan=sloganInput.value;renderDesign();remember(before);persist();toast(loaded.length+' SVG importé'+(loaded.length>1?'s':'')+' : appui long pour les placer');
    }catch(error){toast(error.message||'Impossible d’importer ce fichier');}
    finally{upload.value='';upload.disabled=design.imports.filter(Boolean).length>=3;undo.disabled=!history.length;}
  });
  document.querySelectorAll('.custom-card-tabs button').forEach(button=>button.addEventListener('click',()=>{stop();refreshSize();}));
  document.querySelectorAll('[data-go="card-customize"]').forEach(button=>button.addEventListener('click',refreshSize));
  window.addEventListener('resize',refreshSize);
  if(typeof ResizeObserver!=='undefined'){const observer=new ResizeObserver(refreshSize);cards.forEach(card=>observer.observe(card));}
  window.DeclicCardEditor={renderText,refreshSize};renderDesign();stop();
})();
