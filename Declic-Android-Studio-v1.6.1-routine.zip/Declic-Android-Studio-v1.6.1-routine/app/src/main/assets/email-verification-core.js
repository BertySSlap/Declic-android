(function(root,factory){
  var api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.DeclicEmailVerificationCore=api;
})(typeof self!=='undefined'?self:this,function(){
  'use strict';

  function normalizeEmail(value){
    return String(value||'').trim().toLowerCase();
  }

  function isValidEmail(value){
    var email=normalizeEmail(value);
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email);
  }

  function createRequest(email,now,nonce){
    var normalized=normalizeEmail(email);
    if(!isValidEmail(normalized))return null;
    var issuedAt=Number(now)||Date.now();
    var seed=String(nonce||Math.random().toString(36).slice(2))+normalized+issuedAt;
    var hash=2166136261;
    for(var index=0;index<seed.length;index++){
      hash^=seed.charCodeAt(index);
      hash=Math.imul(hash,16777619);
    }
    return {
      email:normalized,
      token:(hash>>>0).toString(36)+'-'+issuedAt.toString(36),
      issuedAt:issuedAt,
      expiresAt:issuedAt+30*60*1000,
      verified:false
    };
  }

  function verify(request,token,email,now){
    if(!request||request.verified===true)return request&&normalizeEmail(request.email)===normalizeEmail(email);
    if(normalizeEmail(request.email)!==normalizeEmail(email))return false;
    if(String(request.token||'')!==String(token||''))return false;
    return (Number(now)||Date.now())<=Number(request.expiresAt||0);
  }

  return {normalizeEmail:normalizeEmail,isValidEmail:isValidEmail,createRequest:createRequest,verify:verify};
});
