/* Local touch editor. The logo, card number and legal text stay fixed. */
(() => {
  'use strict';
  const cards = [...document.querySelectorAll('.custom-card-preview')];
  function sizeTypography() {
    cards.forEach(card => {
      if (card.clientWidth > 0) card.style.fontSize = (card.clientWidth / 194) + 'px';
    });
  }
  sizeTypography();
  const art = document.getElementById('customCardArtPreview');
  art.dataset.cardElement = 'art';
  document.getElementById('customCardSloganPreview').dataset.cardElement = 'slogan';
  const elements = [...document.querySelectorAll('[data-card-element]')];
  const done = document.getElementById('finishCardEdit');
  const help = document.getElementById('cardEditHelp');
  const pointers = new Map();
  let editing = false, selected = null, timer = null, drag = null, pinch = null;
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem('declic.cardLayout') || '{}') || {}; } catch (_) {}
  const states = new Map(elements.map(el => {
    const v = saved[el.dataset.cardElement] || {};
    return [el, {x: Number.isFinite(v.x) ? v.x : 0, y: Number.isFinite(v.y) ? v.y : 0,
      scale: el === art && Number.isFinite(v.scale) ? Math.max(.35, Math.min(3, v.scale)) : 1}];
  }));
  function render(el) {
    const s = states.get(el), card = el.closest('.custom-card-preview');
    // Normalized offsets preserve positions when the phone width changes.
    el.style.transform = `translate(${s.x * card.clientWidth}px,${s.y * card.clientHeight}px) scale(${s.scale})`;
  }
  function constrain(el) {
    render(el);
    const card = el.closest('.custom-card-preview'), c = card.getBoundingClientRect();
    const r = el.getBoundingClientRect(), s = states.get(el), pad = 8;
    const dx = r.width > c.width - pad * 2 ? c.left + c.width / 2 - (r.left + r.width / 2)
      : Math.max(c.left + pad - r.left, Math.min(0, c.right - pad - r.right));
    const dy = r.height > c.height - pad * 2 ? c.top + c.height / 2 - (r.top + r.height / 2)
      : Math.max(c.top + pad - r.top, Math.min(0, c.bottom - pad - r.bottom));
    s.x += dx / card.clientWidth; s.y += dy / card.clientHeight;
    render(el);
  }
  function save() {
    const data = {};
    states.forEach((s, el) => { data[el.dataset.cardElement] = s; });
    try { localStorage.setItem('declic.cardLayout', JSON.stringify(data)); } catch (_) {}
  }
  function clearHold() { clearTimeout(timer); timer = null; }
  function select(el) {
    elements.forEach(item => item.classList.toggle('element-selected', item === el));
    selected = el;
  }
  function enable() {
    editing = true;
    cards.forEach(card => card.classList.add('editing'));
    done.classList.remove('hidden');
    help.textContent = 'Modification active : maintiens puis déplace un élément. Deux doigts sur le dessin pour zoomer. Le logo reste fixe.';
  }
  function distance() {
    const [a, b] = [...pointers.values()];
    return a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0;
  }
  function stop() {
    clearHold(); pointers.clear(); drag = pinch = null;
    editing = false; select(null);
    cards.forEach(card => card.classList.remove('editing'));
    done.classList.add('hidden');
    help.textContent = 'Positions enregistrées. Appui long sur la carte pour modifier à nouveau.';
    save();
  }
  cards.forEach(card => {
    card.addEventListener('contextmenu', e => e.preventDefault());
    card.addEventListener('dragstart', e => e.preventDefault());
    card.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      e.preventDefault();
      card.setPointerCapture(e.pointerId);
      const target = e.target.closest('[data-card-element]');
      pointers.set(e.pointerId, {x:e.clientX, y:e.clientY});
      if (pointers.size === 2) {
        clearHold(); drag = null;
        if (editing && selected === art && card.contains(art)) {
          pinch = {distance:Math.max(1, distance()), scale:states.get(art).scale};
        }
        return;
      }
      if (pointers.size !== 1) return;
      const start = {x:e.clientX, y:e.clientY};
      clearHold();
      timer = setTimeout(() => {
        enable(); select(target); timer = null;
        if (target) drag = {id:e.pointerId, start, initial:{...states.get(target)}};
      }, 450);
      drag = {pending:true, id:e.pointerId, start};
    });
    card.addEventListener('pointermove', e => {
      if (!pointers.has(e.pointerId)) return;
      e.preventDefault();
      pointers.set(e.pointerId, {x:e.clientX, y:e.clientY});
      if (pinch && selected === art && pointers.size === 2) {
        states.get(art).scale = Math.max(.35, Math.min(3, pinch.scale * distance() / pinch.distance));
        constrain(art); return;
      }
      if (!drag || drag.id !== e.pointerId) return;
      const dx = e.clientX - drag.start.x, dy = e.clientY - drag.start.y;
      if (drag.pending) { if (Math.hypot(dx,dy) > 10) {clearHold(); drag = null;} return; }
      if (!selected) return;
      const s = states.get(selected);
      s.x = drag.initial.x + dx / card.clientWidth;
      s.y = drag.initial.y + dy / card.clientHeight;
      constrain(selected);
    });
    const release = e => {
      pointers.delete(e.pointerId); clearHold(); drag = pinch = null; save();
    };
    card.addEventListener('pointerup', release);
    card.addEventListener('pointercancel', release);
    card.addEventListener('lostpointercapture', release);
  });
  done.addEventListener('click', stop);
  document.getElementById('resetCardLayout').addEventListener('click', () => {
    states.forEach(s => { s.x = 0; s.y = 0; s.scale = 1; });
    stop(); sizeTypography(); elements.forEach(render);
    help.textContent = 'Proportions du modèle rétablies. Ton nom, ton slogan et ton choix de visuel sont conservés.';
  });
  document.querySelectorAll('.custom-card-tabs button').forEach(button => button.addEventListener('click', () => {
    stop(); sizeTypography(); elements.forEach(render);
  }));
  const refreshSize = () => { sizeTypography(); elements.forEach(render); };
  window.addEventListener('resize', refreshSize);
  if (typeof ResizeObserver !== 'undefined') {
    const observer = new ResizeObserver(refreshSize);
    cards.forEach(card => observer.observe(card));
  }
  document.querySelectorAll('[data-go="card-customize"]').forEach(button => button.addEventListener('click', refreshSize));
  elements.forEach(render);
})();
