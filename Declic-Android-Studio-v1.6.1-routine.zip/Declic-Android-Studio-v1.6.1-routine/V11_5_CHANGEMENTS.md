# Déclic Usager 1.5.1-server

- Les enveloppes projet ont maintenant leur propre durée de blocage et leurs propres frais de déblocage anticipé.
- Les fonctions déjà présentes de recharge automatique au seuil, historique réel de cagnotte prototype, graphique 7 jours dynamique et fidélité par commerce sont conservées.
- Les offres commerçant supprimées ou en pause disparaissent automatiquement au prochain cycle de synchronisation.
