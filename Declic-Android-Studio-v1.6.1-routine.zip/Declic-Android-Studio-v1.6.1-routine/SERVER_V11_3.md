# Déclic Usager 1.4.9-server — validation du Point du jour

Avant chaque scan, l'application envoie au serveur :
- le Point Déclic réellement choisi pour aujourd'hui ;
- le planning hebdomadaire quand il peut être relié à un Point serveur ;
- l'heure limite réellement calculée par l'app ;
- la marge silencieuse (3 minutes actuellement).

Le serveur refuse :
- un autre Point Déclic ;
- un scan après l'heure limite + marge ;
- un jour de pause ;
- un jour sans Point concret choisi ;
- une deuxième validation dans la même journée.

Codes serveur principaux :
- `WRONG_POINT_FOR_TODAY`
- `VALIDATION_TOO_LATE`
- `DAY_NOT_ACTIVE`
- `NO_POINT_SELECTED_TODAY`
- `ALREADY_VALIDATED`
- `PERSONAL_CARD_NOT_OWNER`
